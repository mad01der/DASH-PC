// globalState.js
export const globalState = {
    bandwidthIncrease: 0,
    bandwidth:0,
    currentQualityLevel:-1,
    i:-1,
    fps:0,
    is_loading:1,
    // ABR算法相关状态
    currentABRAlgorithm: 'buffer-based', // 当前选择的ABR算法
    abrAlgorithmHistory: [], // ABR算法切换历史
    bufferUsageRate: 0, // 缓冲区使用率
    abrChunkQualityByChunk: {}, // 每个chunk的ABR决策质量
    // 视口预测算法相关状态
    currentViewportPredictionAlgorithm: 'lr', // 当前选择的视口预测算法
    viewportPredictionHistory: [], // 视口预测算法切换历史
    // WebXR相关状态
    webxrSupported: false, // 是否支持WebXR
    webxrSessionActive: false, // WebXR会话是否激活
    webxrDeviceType: null, // WebXR设备类型 (VR/AR)
    webxrControllerCount: 0 // 可用的控制器数量
};
