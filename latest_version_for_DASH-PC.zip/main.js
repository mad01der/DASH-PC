import * as THREE from 'three';
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
import camera from "./src/camera";
import scene from "./src/scene";
import { fetchAndParseMPD_show, play_control_tbb } from "./dash_pc";
import { viewportPredictionManager } from "./src/viewport/ViewportPredictionManager.js";
import { globalState } from "./global.js";

// WebXR管理器
class WebXRManager {
  constructor(renderer, scene, camera) {
    this.renderer = renderer;
    this.scene = scene;
    this.camera = camera;
    this.session = null;
    this.isActive = false;
    this.controllers = [];
    this.controllerGrips = [];
    
    // 检查WebXR支持
    this.checkSupport();
  }
  
  checkSupport() {
    if (navigator.xr) {
      navigator.xr.isSessionSupported('immersive-vr').then((supported) => {
        globalState.webxrSupported = supported;
        globalState.webxrDeviceType = supported ? 'VR' : null;
        console.log(`[WebXR] VR支持状态: ${supported}`);
      }).catch((error) => {
        globalState.webxrSupported = false;
        console.error('[WebXR] 检查VR支持失败:', error);
      });
    } else {
      globalState.webxrSupported = false;
      console.log('[WebXR] 浏览器不支持WebXR');
    }
  }
  
  async startSession() {
    if (!globalState.webxrSupported) {
      throw new Error('WebXR不支持');
    }
    
    try {
      const session = await navigator.xr.requestSession('immersive-vr', {
        optionalFeatures: ['local-floor', 'bounded-floor', 'hand-tracking']
      });
      
      this.session = session;
      this.isActive = true;
      globalState.webxrSessionActive = true;
      
      // 设置渲染器会话
      this.renderer.xr.setSession(session);
      
      // 创建控制器
      this.createControllers();
      
      // 创建VR环境
      this.createVREnvironment();
      
      // 设置会话事件
      session.addEventListener('end', () => this.endSession());
      
      console.log('[WebXR] 会话已启动');
      return true;
      
    } catch (error) {
      console.error('[WebXR] 启动会话失败:', error);
      throw error;
    }
  }
  
  endSession() {
    if (this.session) {
      this.session.end();
      this.session = null;
      this.isActive = false;
      globalState.webxrSessionActive = false;
      
      // 清理控制器
      this.cleanupControllers();
      
      // 清理VR环境
      this.cleanupVREnvironment();
      
      console.log('[WebXR] 会话已结束');
    }
  }
  
  createControllers() {
    // 创建两个控制器
    for (let i = 0; i < 2; i++) {
      const controller = this.renderer.xr.getController(i);
      controller.addEventListener('selectstart', this.onSelectStart.bind(this));
      controller.addEventListener('selectend', this.onSelectEnd.bind(this));
      this.scene.add(controller);
      this.controllers.push(controller);
      
      // 创建控制器握把
      const grip = this.renderer.xr.getControllerGrip(i);
      this.scene.add(grip);
      this.controllerGrips.push(grip);
      
      // 添加控制器可视化
      const geometry = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, 0, -1)
      ]);
      
      const line = new THREE.Line(geometry);
      line.name = 'controller-line';
      line.scale.z = 5;
      
      controller.add(line);
    }
    
    globalState.webxrControllerCount = this.controllers.length;
    console.log(`[WebXR] 已创建 ${this.controllers.length} 个控制器`);
  }
  
  cleanupControllers() {
    this.controllers.forEach(controller => {
      this.scene.remove(controller);
    });
    this.controllerGrips.forEach(grip => {
      this.scene.remove(grip);
    });
    
    this.controllers = [];
    this.controllerGrips = [];
    globalState.webxrControllerCount = 0;
  }
  
  createVREnvironment() {
    // 创建地面
    const groundGeometry = new THREE.PlaneGeometry(20, 20);
    const groundMaterial = new THREE.MeshBasicMaterial({ 
      color: 0x444444, 
      transparent: true, 
      opacity: 0.3,
      side: THREE.DoubleSide 
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -2;
    ground.name = 'vr-ground';
    this.scene.add(ground);
    
    // 创建环境光
    const light = new THREE.AmbientLight(0xffffff, 0.6);
    light.name = 'vr-light';
    this.scene.add(light);
  }
  
  cleanupVREnvironment() {
    const ground = this.scene.getObjectByName('vr-ground');
    if (ground) this.scene.remove(ground);
    
    const light = this.scene.getObjectByName('vr-light');
    if (light) this.scene.remove(light);
  }
  
  onSelectStart(event) {
    const controller = event.target;
    const intersections = this.getIntersections(controller);
    
    if (intersections.length > 0) {
      const intersection = intersections[0];
      console.log('[WebXR] 选择对象:', intersection.object.name || '未命名');
    }
  }
  
  onSelectEnd(event) {
    console.log('[WebXR] 选择结束');
  }
  
  getIntersections(controller) {
    const tempMatrix = new THREE.Matrix4();
    tempMatrix.identity().extractRotation(controller.matrixWorld);
    
    const raycaster = new THREE.Raycaster();
    raycaster.ray.origin.setFromMatrixPosition(controller.matrixWorld);
    raycaster.ray.direction.set(0, 0, -1).applyMatrix4(tempMatrix);
    
    return raycaster.intersectObjects(this.scene.children, true);
  }
}

// 在页面加载时插入loading动画元素（只插入一次）
export function init3DView(container){
  // 确保只插入一次loading动画到container
  if (!container.querySelector('#loading-spinner')) {
    const spinner = document.createElement('div');
    spinner.id = 'loading-spinner';
    spinner.style.display = 'none';
    spinner.style.position = 'absolute';
    spinner.style.left = '0';
    spinner.style.top = '0';
    spinner.style.width = '100%';
    spinner.style.height = '100%';
    spinner.style.background = 'rgba(255,255,255,0.7)';
    spinner.style.zIndex = '9999';
    spinner.style.justifyContent = 'center';
    spinner.style.alignItems = 'center';
    spinner.style.pointerEvents = 'auto';
    spinner.style.display = 'none';
    spinner.style.flexDirection = 'column';
    
    // 旋转圈
    const circle = document.createElement('div');
    circle.style.border = '8px solid #f3f3f3';
    circle.style.borderTop = '8px solid #3498db';
    circle.style.borderRadius = '50%';
    circle.style.width = '60px';
    circle.style.height = '60px';
    circle.style.animation = 'spin 1s linear infinite';
    spinner.appendChild(circle);
    
    // 进度条容器
    const progressBarContainer = document.createElement('div');
    progressBarContainer.style.width = '240px';
    progressBarContainer.style.height = '16px';
    progressBarContainer.style.background = '#e5e7eb';
    progressBarContainer.style.borderRadius = '8px';
    progressBarContainer.style.margin = '32px 0 8px 0';
    progressBarContainer.style.overflow = 'hidden';
    
    // 进度条
    const progressBar = document.createElement('div');
    progressBar.id = 'loading-progress-bar';
    progressBar.style.height = '100%';
    progressBar.style.width = '0%';
    progressBar.style.background = 'linear-gradient(90deg, #667eea, #764ba2)';
    progressBar.style.transition = 'width 0.2s linear';
    progressBarContainer.appendChild(progressBar);
    spinner.appendChild(progressBarContainer);
    
    // 百分比文本
    const percentText = document.createElement('div');
    percentText.id = 'loading-percent-text';
    percentText.textContent = '0%';
    percentText.style.fontSize = '16px';
    percentText.style.color = '#374151';
    percentText.style.fontWeight = '500';
    percentText.style.marginBottom = '8px';
    spinner.appendChild(percentText);
    
    // 动画样式
    const style = document.createElement('style');
    style.textContent = `
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    `;
    document.head.appendChild(style);
    container.style.position = container.style.position || 'relative';
    container.appendChild(spinner);
  }
  camera.position.z = 150;
  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setClearColor(0xffffff, 1); // 设置背景为白色，解决黑色闪烁问题
  renderer.xr.enabled = true;
  
  // 创建WebXR管理器
  const webXRManager = new WebXRManager(renderer, scene, camera);
  
  // 监听WebXR请求事件
  window.addEventListener('webxrRequested', async (event) => {
    if (event.detail.action === 'start') {
      try {
        await webXRManager.startSession();
        // 更新按钮状态
        updateWebXRButtonState(true);
      } catch (error) {
        alert('启动VR失败，请检查您的VR设备连接');
        console.error('[WebXR] 启动失败:', error);
        // 恢复按钮状态
        updateWebXRButtonState(false);
      }
    }
  });
  
  // 更新WebXR按钮状态
  const updateWebXRButtonState = (inVR) => {
    const webxrButton = document.getElementById('webxr-button');
    if (webxrButton) {
      if (inVR) {
        webxrButton.textContent = '🥽 退出VR';
        webxrButton.style.background = 'linear-gradient(135deg, #ef4444, #dc2626)';
        webxrButton.onclick = () => {
          webXRManager.endSession();
          updateWebXRButtonState(false);
        };
      } else {
        webxrButton.textContent = '🥽 WebXR';
        webxrButton.style.background = 'linear-gradient(135deg, #f093fb, #667eea)';
        webxrButton.onclick = null;
      }
    }
  };
  
  if (!document.querySelector('canvas')) {
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.domElement.style.marginLeft = "15px";
    renderer.domElement.style.marginTop = '4px';
    renderer.setSize(window.innerWidth / 1.5, window.innerHeight / 1.5);
    container.appendChild(renderer.domElement);
  }
  const loader = new DRACOLoader();
  loader.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.5.6/');
  loader.setDecoderConfig({ type: 'js' });
  loader.preload();
  document.getElementById('startButton').addEventListener('click', async function () {
    // 直接使用硬编码的MPD URL，不再从输入框获取
    const mpdUrl = 'https://localhost/drc_scable/pointcloud.mpd';
    const spinner = container.querySelector('#loading-spinner');
    const progressBar = spinner.querySelector('#loading-progress-bar');
    const percentText = spinner.querySelector('#loading-percent-text');
    if (mpdUrl.includes('Flask_server')) {
      spinner.style.display = 'flex'; 
      progressBar.style.width = '0%';
      percentText.textContent = '0%';
      let progress = 0;
      const duration = 60000; // 60秒
      const interval = 100; // ms
      const steps = duration / interval;
      let currentStep = 0;
      const timer = setInterval(() => {
        currentStep++;
        progress = Math.min(100, Math.round((currentStep / steps) * 100));
        progressBar.style.width = progress + '%';
        percentText.textContent = progress + '%';
        if (progress >= 100) {
          clearInterval(timer);
        }
      }, interval);
      try {
        const response = await fetch('https://localhost:5000/start_preload', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          }
        });
        if (!response.ok) {
          console.error('预加载信号发送失败:', response.status);
        } else {
          console.log('预加载信号发送成功');
        }
      } catch (error) {
        console.error('发送预加载信号时出错:', error);
      }
      await new Promise(resolve => setTimeout(resolve, duration));
      clearInterval(timer);
      progressBar.style.width = '100%';
      percentText.textContent = '100%';
      setTimeout(() => {
        spinner.style.display = 'none';
      }, 300);
      const representations = await fetchAndParseMPD_show(mpdUrl);
      play_control_tbb(representations);
    } else {
      const representations = await fetchAndParseMPD_show(mpdUrl);
      play_control_tbb(representations);
    }
  });
  const controls = new OrbitControls(camera, renderer.domElement);
  
  // 修改动画循环以支持VR
  function animation() {
    // 只在非VR模式下更新OrbitControls
    if (!webXRManager.isActive) { // 使用webXRManager.isActive判断VR状态
      controls.update();
    }
    
    // 渲染场景
    renderer.render(scene, camera);
    
    // 在VR模式下使用setAnimationLoop
    if (webXRManager.isActive) { // 使用webXRManager.isActive判断VR状态
      // VR模式下的渲染循环由WebXR处理
    } else {
      requestAnimationFrame(animation);
    }
  }
  
  // 启动动画循环
  animation();
  
  // 设置VR渲染循环
  renderer.setAnimationLoop((time, frame) => {
    if (webXRManager.isActive && frame) { // 使用webXRManager.isActive判断VR状态
      // VR模式下的渲染
      renderer.render(scene, camera);
    }
  });
  window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth / 1.5, window.innerHeight / 1.5);
  });

  // 添加ABR算法切换事件监听器
  window.addEventListener('abrAlgorithmChanged', (event) => {
    const selectedAlgorithm = event.detail.algorithm;
    console.log(`[主程序] ABR算法切换到: ${selectedAlgorithm}`);
    
    // 更新全局状态
    if (window.globalState) {
      window.globalState.currentABRAlgorithm = selectedAlgorithm;
      
      // 记录算法切换历史
      if (!window.globalState.abrAlgorithmHistory) {
        window.globalState.abrAlgorithmHistory = [];
      }
      window.globalState.abrAlgorithmHistory.push({
        timestamp: Date.now(),
        algorithm: selectedAlgorithm
      });
    }
    
    // 如果ABR管理器可用，更新算法
    if (window.abrManager) {
      window.abrManager.setAlgorithm(selectedAlgorithm);
    }
  });

  // 添加视口预测算法切换事件监听器
  window.addEventListener('viewportPredictionChanged', (event) => {
    const selectedAlgorithm = event.detail.algorithm;
    console.log(`[主程序] 视口预测算法切换到: ${selectedAlgorithm}`);
    
    // 更新全局状态
    if (window.globalState) {
      window.globalState.currentViewportPredictionAlgorithm = selectedAlgorithm;
      
      // 记录算法切换历史
      if (!window.globalState.viewportPredictionHistory) {
        window.globalState.viewportPredictionHistory = [];
      }
      window.globalState.viewportPredictionHistory.push({
        timestamp: Date.now(),
        algorithm: selectedAlgorithm
      });
    }
    
    // 更新视口预测管理器算法
    if (viewportPredictionManager) {
      viewportPredictionManager.setAlgorithm(selectedAlgorithm);
    }
  });

  // 将视口预测管理器暴露到全局作用域
  window.viewportPredictionManager = viewportPredictionManager;
}