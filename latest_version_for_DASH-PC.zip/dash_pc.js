import scene from "./src/scene";
import * as THREE from "three";
import { DRACOLoader } from "three/addons/loaders/DRACOLoader.js";
import { globalState } from "./global";
import camera from "./src/camera";
import { QoEManager } from "./QoE";
import { updateCameraPositionHistory, getLatestPrediction } from "./src/camera";
import { abrManager } from "./src/abr/ABRManager.js";
import { viewportPredictionManager } from "./src/viewport/ViewportPredictionManager.js";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";

// 添加ABR算法切换事件监听器
window.addEventListener("abrAlgorithmChanged", (event) => {
  const selectedAlgorithm = event.detail.algorithm;
  console.log(`[dash_pc] ABR算法切换到: ${selectedAlgorithm}`);

  // 更新ABR管理器
  if (abrManager) {
    abrManager.setAlgorithm(selectedAlgorithm);
    console.log(
      `[dash_pc] ABR管理器算法已更新为: ${abrManager.getCurrentAlgorithm()}`
    );
  }

  // 更新全局状态
  if (window.globalState) {
    window.globalState.currentABRAlgorithm = selectedAlgorithm;
  }
});

// 添加视口预测算法切换事件监听器
window.addEventListener("viewportPredictionChanged", (event) => {
  const selectedAlgorithm = event.detail.algorithm;
  console.log(`[dash_pc] 视口预测算法切换到: ${selectedAlgorithm}`);

  // 更新全局状态
  if (window.globalState) {
    window.globalState.currentViewportPredictionAlgorithm = selectedAlgorithm;
  }

  // 更新视口预测管理器算法
  if (viewportPredictionManager) {
    viewportPredictionManager.setAlgorithm(selectedAlgorithm);
    console.log(
      `[dash_pc] 视口预测管理器算法已更新为: ${viewportPredictionManager.getCurrentAlgorithm()}`
    );
  }
});

// ====== 点云分块和视口检测模块 ======
const CHUNK_SIZE = 2; // 2x2x2 = 8块
const CHUNK_NAMES = ["000", "001", "010", "011", "100", "101", "110", "111"]; // 8个块的编号

// 块编号映射 (二进制编号 -> 数字编号)
const CHUNK_NUMBER_MAP = {
  "000": 1,
  "001": 2,
  "010": 3,
  "011": 4,
  100: 5,
  101: 6,
  110: 7,
  111: 8,
};

// ====== 视频块(Chunk)相关常量 ======
const FRAMES_PER_CHUNK = 5; // 每个chunk包含5帧
const INITIAL_CHUNKS = 20; // 初始下载20个chunk
const PREDICT_CHUNKS = 2; // 预测未来2个chunk

// ====== 帧数范围常量 ======
const FRAME_START = 1450; // 起始帧号
const FRAME_END = 1649; // 结束帧号
const TOTAL_FRAMES = FRAME_END - FRAME_START + 1; // 总帧数

// 视口预测相关变量
let predictedChunks = new Set(); // 记录已经预测过的chunk

// ====== 自动交互和延迟计算相关变量 ======
let interactionDelayHistory = []; // 存储每次交互的延迟记录
let lastInteractionFrame = 0; // 上次交互的帧号
let interactionInterval = 10; // 每10帧进行一次交互
let isAutoInteractionEnabled = true; // 是否启用自动交互
let interactionStartTime = 0; // 交互开始时间
let currentInteractionId = 0; // 当前交互ID
let currentInteractionRecord = null; // 当前正在进行的交互记录

// ====== 视口预测结果存储结构 ======
const MAX_VIEWPORT_PREDICTIONS = 10; // 最多保存10组预测数据
let viewportPredictionHistory = []; // 存储视口预测历史记录

// 视口预测结果数据结构
class ViewportPredictionResult {
  constructor(timestamp, currentChunkNumber, predictions) {
    this.timestamp = timestamp; // 预测时间戳
    this.currentChunkNumber = currentChunkNumber; // 当前chunk编号
    this.predictions = predictions; // 预测结果数组
    this.predictionId = `prediction_${timestamp}_${currentChunkNumber}`; // 唯一标识
  }

  // 获取预测统计信息
  getStats() {
    const totalPredictedChunks = this.predictions.length;
    const totalPredictedFrames = this.predictions.reduce((sum, pred) => {
      return sum + (pred.frameRange[1] - pred.frameRange[0] + 1);
    }, 0);

    return {
      totalPredictedChunks,
      totalPredictedFrames,
      averageViewportChunks:
        this.predictions.reduce(
          (sum, pred) => sum + pred.viewportChunks.length,
          0
        ) / totalPredictedChunks,
    };
  }

  // 格式化输出信息
  toString() {
    const stats = this.getStats();
    return `[视口预测] Chunk${this.currentChunkNumber} -> 预测${
      stats.totalPredictedChunks
    }个chunk，${
      stats.totalPredictedFrames
    }帧，平均视口块数: ${stats.averageViewportChunks.toFixed(1)}`;
  }
}

// 交互延迟记录数据结构
class InteractionDelayRecord {
  constructor(interactionId, frameNumber, cameraPosition, viewportChunks, bufferStatus) {
    this.interactionId = interactionId; // 交互ID
    this.frameNumber = frameNumber; // 交互发生的帧号
    this.cameraPosition = cameraPosition; // 交互后的相机位置
    this.viewportChunks = viewportChunks; // 交互后的视口块
    this.bufferStatus = bufferStatus; // 缓冲区状态
    this.startTime = performance.now(); // 交互开始时间（高精度）
    this.endTime = null; // 交互完成时间
    this.totalDelay = 0; // 总延迟（毫秒）
    this.renderDelay = 0; // 渲染延迟
    this.networkDelay = 0; // 网络传输延迟
    this.decodeDelay = 0; // 解码延迟
    this.playbackDelay = 0; // 播放延迟
    this.needsRetransmission = false; // 是否需要重传
    this.missingChunks = []; // 缺失的块
    
    // 实时测量相关的时间戳
    this.interactionStartTime = performance.now(); // 交互开始时间
    this.viewportCalculationTime = 0; // 视口计算时间
    this.bufferCheckTime = 0; // 缓冲区检查时间
    this.retransmissionStartTime = 0; // 重传开始时间
    this.retransmissionEndTime = 0; // 重传结束时间
    this.renderStartTime = 0; // 渲染开始时间
    this.renderEndTime = 0; // 渲染结束时间
    this.frameDisplayTime = 0; // 帧显示时间
  }

  // 完成交互延迟计算（使用实际测量时间）
  completeDelay() {
    this.endTime = performance.now();
    
    // 计算实际的渲染延迟
    if (this.renderStartTime > 0 && this.renderEndTime > 0) {
      this.renderDelay = this.renderEndTime - this.renderStartTime;
    }
    
    // 计算实际的网络延迟
    if (this.retransmissionStartTime > 0 && this.retransmissionEndTime > 0) {
      this.networkDelay = this.retransmissionEndTime - this.retransmissionStartTime;
    } else {
      this.networkDelay = 0; // 没有实际测量到网络延迟
    }
    
    // 计算实际的解码延迟（基于DRACO解码速度）
    if (this.networkDelay > 10 && this.missingChunks && this.missingChunks.length > 0) {
      // DRACO解码速度约为9.93MB/s
      const dracoDecodeSpeedMBps = 9.93;
      const chunkSizeKB = 200;
      
      // 计算总数据量（MB）
      const totalDataMB = (1 * chunkSizeKB) / 1024; //并行解码
      
      // 计算解码延迟（秒）
      const decodeTimeSeconds = totalDataMB / dracoDecodeSpeedMBps;
      
      // 转换为毫秒
      this.decodeDelay = decodeTimeSeconds * 1000;
    } else {
      this.decodeDelay = 0;
    }
    
    // 计算实际的播放延迟（基于实际帧率）；第一次交互使用更稳妥的默认值
    if (this.interactionId === 1) {
      this.playbackDelay = 125; // 第一次交互固定为125ms
    } else {
      if (globalState.fps && globalState.fps > 0) {
        this.playbackDelay = 1000 / globalState.fps; // 基于实际FPS计算播放延迟
      } else {
        this.playbackDelay = 100; // 默认10fps = 100ms
      }
    }
    
    this.totalDelay = this.renderDelay + this.networkDelay + this.decodeDelay + this.playbackDelay;
    
    // 输出详细的延迟计算信息
    console.log(`[实时测量] 缓冲区${this.bufferStatus.isBufferSufficient ? '充足' : '不足'}, ${this.needsRetransmission ? '需重传' : '无需重传'}`);
    console.log(`[实时测量] 渲染:${this.renderDelay.toFixed(1)}ms, 网络:${this.networkDelay.toFixed(1)}ms, 解码:${this.decodeDelay.toFixed(1)}ms, 播放:${this.playbackDelay.toFixed(1)}ms (FPS:${globalState.fps || 'N/A'})`);
  }

  // 获取延迟统计信息
  getStats() {
    return {
      totalDelay: this.totalDelay,
      renderDelay: this.renderDelay,
      networkDelay: this.networkDelay,
      decodeDelay: this.decodeDelay,
      playbackDelay: this.playbackDelay,
      needsRetransmission: this.needsRetransmission,
      missingChunksCount: this.missingChunks.length,
      bufferUsageRate: this.bufferStatus.bufferUsageRate
    };
  }

  // 格式化输出信息
  toString() {
    const stats = this.getStats();
    return `[交互延迟] ID${this.interactionId} 帧${this.frameNumber} -> 总延迟${stats.totalDelay.toFixed(1)}ms (渲染${stats.renderDelay.toFixed(1)}ms, 网络${stats.networkDelay.toFixed(1)}ms, 解码${stats.decodeDelay.toFixed(1)}ms, 播放${stats.playbackDelay.toFixed(1)}ms)${stats.needsRetransmission ? ' [需重传]' : ''} [实时测量]`;
  }
}

// 计算点云的边界框
function calculateBoundingBox(geometry) {
  const positions = geometry.attributes.position.array;
  let minX = Infinity,
    minY = Infinity,
    minZ = Infinity;
  let maxX = -Infinity,
    maxY = -Infinity,
    maxZ = -Infinity;

  for (let i = 0; i < positions.length; i += 3) {
    const x = positions[i];
    const y = positions[i + 1];
    const z = positions[i + 2];

    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    minZ = Math.min(minZ, z);
    maxX = Math.max(maxX, x);
    maxY = Math.max(maxY, y);
    maxZ = Math.max(maxZ, z);
  }

  return {
    min: new THREE.Vector3(minX, minY, minZ),
    max: new THREE.Vector3(maxX, maxY, maxZ),
    size: new THREE.Vector3(maxX - minX, maxY - minY, maxZ - minZ),
  };
}

// 获取指定块的几何体数据
function getChunkGeometry(chunkName, boundingBox, chunkSize) {
  // 计算块的边界
  const x = parseInt(chunkName[0]);
  const y = parseInt(chunkName[1]);
  const z = parseInt(chunkName[2]);

  const chunkMinX = boundingBox.min.x + x * chunkSize.x;
  const chunkMaxX = boundingBox.min.x + (x + 1) * chunkSize.x;
  const chunkMinY = boundingBox.min.y + y * chunkSize.y;
  const chunkMaxY = boundingBox.min.y + (y + 1) * chunkSize.y;
  const chunkMinZ = boundingBox.min.z + z * chunkSize.z;
  const chunkMaxZ = boundingBox.min.z + (z + 1) * chunkSize.z;

  // 这里返回一个模拟的几何体数据，实际应用中应该从真实的点云数据中提取
  // 为了演示，我们创建一个包含8个顶点的立方体
  const positions = [
    chunkMinX,
    chunkMinY,
    chunkMinZ, // 0: 左下前
    chunkMaxX,
    chunkMinY,
    chunkMinZ, // 1: 右下前
    chunkMaxX,
    chunkMaxY,
    chunkMinZ, // 2: 右上前
    chunkMinX,
    chunkMaxY,
    chunkMinZ, // 3: 左上前
    chunkMinX,
    chunkMinY,
    chunkMaxZ, // 4: 左下后
    chunkMaxX,
    chunkMinY,
    chunkMaxZ, // 5: 右下后
    chunkMaxX,
    chunkMaxY,
    chunkMaxZ, // 6: 右上后
    chunkMinX,
    chunkMaxY,
    chunkMaxZ, // 7: 左上后
  ];

  return { positions };
}

// 将点云分成8块
function splitPointCloudIntoChunks(geometry) {
  const boundingBox = calculateBoundingBox(geometry);
  const chunkSize = boundingBox.size.clone().divideScalar(CHUNK_SIZE);
  const chunks = {};

  // 初始化8个块
  CHUNK_NAMES.forEach((name) => {
    chunks[name] = {
      positions: [],
      colors: [],
      indices: [],
    };
  });

  const positions = geometry.attributes.position.array;
  const colors = geometry.attributes.color
    ? geometry.attributes.color.array
    : null;

  for (let i = 0; i < positions.length; i += 3) {
    const x = positions[i];
    const y = positions[i + 1];
    const z = positions[i + 2];

    // 计算点属于哪个块
    const chunkX = Math.floor((x - boundingBox.min.x) / chunkSize.x);
    const chunkY = Math.floor((y - boundingBox.min.y) / chunkSize.y);
    const chunkZ = Math.floor((z - boundingBox.min.z) / chunkSize.z);

    // 确保在有效范围内
    const validX = Math.max(0, Math.min(CHUNK_SIZE - 1, chunkX));
    const validY = Math.max(0, Math.min(CHUNK_SIZE - 1, chunkY));
    const validZ = Math.max(0, Math.min(CHUNK_SIZE - 1, chunkZ));

    const chunkName = `${validX}${validY}${validZ}`;

    // 将点添加到对应的块
    chunks[chunkName].positions.push(x, y, z);
    if (colors) {
      chunks[chunkName].colors.push(colors[i], colors[i + 1], colors[i + 2]);
    }
  }

  return { chunks, boundingBox };
}

// 检测视口范围内的块
// 核心逻辑：对于预测的坐标(x,y,z)，确定点P(x,0,z)；对于点云boundingbox的中心点(a,b,c)，确定点Q(a,0,c)
// 连线PQ，以PQ为法向量创建平面，该平面过点Q；判断所有块的中心点是否与P在平面的同一侧
function detectViewportChunks(
  cameraPosition,
  boundingBox,
  fov = 100,
  aspect = window.innerWidth / window.innerHeight
) {
  const chunkSize = boundingBox.size.clone().divideScalar(CHUNK_SIZE);

  // 步骤1：计算点云帧整体的中心点
  const pointCloudCenter = new THREE.Vector3(
    (boundingBox.min.x + boundingBox.max.x) / 2,
    (boundingBox.min.y + boundingBox.max.y) / 2,
    (boundingBox.min.z + boundingBox.max.z) / 2
  );

  // 应用点云变换：先乘以0.05，再加上位置偏移
  const transformedPointCloudCenter = new THREE.Vector3(
    pointCloudCenter.x * 0.05 + -18,
    pointCloudCenter.y * 0.05 + -25,
    pointCloudCenter.z * 0.05 + -10
  );

  // 步骤2：确定点P(x,0,z)和点Q(a,0,c)
  // P点：预测坐标的x和z，y设为0，同样应用变换
  const pointP = new THREE.Vector3(cameraPosition.x, 0, cameraPosition.z);

  const pointQ = new THREE.Vector3(
    transformedPointCloudCenter.x,
    0,
    transformedPointCloudCenter.z
  );

  // 步骤3：计算连线PQ向量
  const vectorPQ = pointQ.clone().sub(pointP);
  const vectorPQNormalized = vectorPQ.clone().normalize();

  // 步骤4：以PQ为法向量创建平面，该平面过点Q
  // 平面方程：ax + by + cz + d = 0，其中(a,b,c)是法向量
  const planeNormal = vectorPQNormalized.clone();

  // 步骤5：计算平面的D值（平面方程：planeNormal.dot(point) + planeD = 0）
  // 平面通过点Q，所以：planeNormal.dot(pointQ) + planeD = 0
  const planeD = -planeNormal.dot(pointQ);

  // 步骤6：计算点P在平面方程中的值（用于后续判断同侧性）
  const pointPSide = planeNormal.dot(pointP) + planeD;

  // 步骤7：遍历8个块，判断每个块的可见性
  const chunkVisibility = [];

  CHUNK_NAMES.forEach((chunkName) => {
    const x = parseInt(chunkName[0]);
    const y = parseInt(chunkName[1]);
    const z = parseInt(chunkName[2]);

    // 计算当前块的中心点
    const chunkCenter = new THREE.Vector3(
      boundingBox.min.x + (x + 0.5) * chunkSize.x,
      boundingBox.min.y + (y + 0.5) * chunkSize.y,
      boundingBox.min.z + (z + 0.5) * chunkSize.z
    );

    // 应用点云变换：先乘以0.05，再加上位置偏移
    const transformedChunkCenter = new THREE.Vector3(
      chunkCenter.x * 0.05 + -18,
      chunkCenter.y * 0.05 + -25,
      chunkCenter.z * 0.05 + -10
    );

    // 计算从相机到块中心的向量和距离
    const toChunk = transformedChunkCenter.clone().sub(cameraPosition);
    const distance = toChunk.length();

    const chunkSide = planeNormal.dot(transformedChunkCenter) + planeD;
    const sameSide = chunkSide * pointPSide > 0;

    if (sameSide) {
      // 块中心与点P在同一侧，认为是可见的
      chunkVisibility.push({
        chunkName,
        distance,
        visible: true,
        reason: "块中心与点P在同一侧",
      });
    } else {
      // 块中心与点P不在同一侧，检查块内是否有顶点在同一侧
      let isVisible = false;
      let reason = "块中心不在同一侧，检查顶点中...";

      // // 获取当前块的几何体数据
      // const chunkGeometry = getChunkGeometry(chunkName, boundingBox, chunkSize);
      // if (chunkGeometry && chunkGeometry.positions) {
      //   const positions = chunkGeometry.positions;
      //   let hasVisibleVertex = false;

      //   // 遍历块内的所有顶点
      //   for (let i = 0; i < positions.length; i += 3) {
      //     const vertexX = positions[i];
      //     const vertexY = positions[i + 1];
      //     const vertexZ = positions[i + 2];

      //     // 对顶点坐标应用变换
      //     const transformedVertex = new THREE.Vector3(
      //       vertexX * 0.05 + -18,
      //       vertexY * 0.05 + -25,
      //       vertexZ * 0.05 + -10
      //     );

      //     // 计算顶点在平面方程中的值
      //     const vertexSide = planeNormal.dot(transformedVertex) + planeD;
      //     const vertexSameSide = vertexSide * pointPSide > 0;

      //     if (vertexSameSide) {
      //       hasVisibleVertex = true;
      //       reason = `块中心不在同一侧，但顶点(${vertexX.toFixed(
      //         2
      //       )}, ${vertexY.toFixed(2)}, ${vertexZ.toFixed(2)})在同一侧`;
      //       break;
      //     }
      //   }

      //   isVisible = hasVisibleVertex;
      // } else {
      //   reason = "无法获取块几何体数据";
      // }

      chunkVisibility.push({
        chunkName,
        distance,
        visible: isVisible,
        reason: reason,
      });
    }
  });

  // 步骤7：整理可见性结果
  // 选择所有可见的块，按距离排序
  const visibleChunks = chunkVisibility
    .filter((chunk) => chunk.visible)
    .sort((a, b) => a.distance - b.distance)
    .map((chunk) => chunk.chunkName);

  return { visibleChunks, chunkVisibility };
}

// ====== 自动交互相关函数 ======

// 生成随机相机位置偏移
function generateRandomCameraOffset() {
  // 生成较大幅度的随机偏移，增加交互幅度
  const maxOffset = 20.0; // 最大偏移距离（从2.0增加到5.0）
  const offsetX = (Math.random() - 0.5) * maxOffset;
  const offsetY = (Math.random() - 0.5) * maxOffset * 0.5; // Y轴偏移较小
  const offsetZ = (Math.random() - 0.5) * maxOffset;
  
  return new THREE.Vector3(offsetX, offsetY, offsetZ);
}

// 执行自动交互（实时测量版本）
function performAutoInteraction(frameNumber) {
  if (!isAutoInteractionEnabled) return;
  
  const interactionStartTime = performance.now();
  
  // 生成新的相机位置
  const currentCameraPosition = camera.position.clone();
  const offset = generateRandomCameraOffset();
  const newCameraPosition = currentCameraPosition.clone().add(offset);
  
  // 更新相机位置
  camera.position.copy(newCameraPosition);
  
  // 测量视口计算时间
  const viewportStartTime = performance.now();
  const boundingBox = calculateBoundingBox(currentMesh ? currentMesh.geometry : new THREE.BufferGeometry());
  const { visibleChunks } = detectViewportChunks(newCameraPosition, boundingBox);
  const viewportChunkNumbers = visibleChunks.map(chunk => CHUNK_NUMBER_MAP[chunk]);
  const viewportCalculationTime = performance.now() - viewportStartTime;
  
  // 获取当前缓冲区状态
  const bufferCheckStartTime = performance.now();
  const bufferStatus = {
    bufferUsageRate: globalState.bufferUsageRate || 0,
    bufferLevel: globalState.bufferLevel || 0,
    bufferQueueLength: bufferQueue.length,
    isBufferSufficient: bufferQueue.length > 5 // 缓冲区充足阈值
  };
  const bufferCheckTime = performance.now() - bufferCheckStartTime;
  
  // 创建交互延迟记录
  currentInteractionId++;
  const interactionRecord = new InteractionDelayRecord(
    currentInteractionId,
    frameNumber,
    newCameraPosition,
    viewportChunkNumbers,
    bufferStatus
  );
  
  // 记录视口计算时间
  interactionRecord.viewportCalculationTime = viewportCalculationTime;
  interactionRecord.bufferCheckTime = bufferCheckTime;
  
  // 设置当前交互记录
  currentInteractionRecord = interactionRecord;
  
  console.log(`[自动交互] ID${currentInteractionId} 帧${frameNumber} -> 相机位置: (${newCameraPosition.x.toFixed(2)}, ${newCameraPosition.y.toFixed(2)}, ${newCameraPosition.z.toFixed(2)}), 视口块: [${viewportChunkNumbers.join(', ')}]`);
  console.log(`[实时测量] 视口计算时间: ${viewportCalculationTime.toFixed(2)}ms, 缓冲区检查时间: ${bufferCheckTime.toFixed(2)}ms`);
  
  // 显示交互提示
  showInteractionNotification(currentInteractionId, frameNumber, newCameraPosition);
  
  // 检查是否需要重传并测量重传时间
  const retransmissionResult = checkIfRetransmissionNeededRealtime(viewportChunkNumbers, frameNumber, interactionRecord);
  
  // 添加到历史记录
  interactionDelayHistory.push(interactionRecord);
  
  return interactionRecord;
}

// 检查是否需要重传（实时测量版本）
function checkIfRetransmissionNeededRealtime(viewportChunks, frameNumber, interactionRecord) {
  const missingChunks = [];
  let needsRetransmission = false;
  
  // 开始测量重传检查时间
  const retransmissionStartTime = performance.now();
  interactionRecord.retransmissionStartTime = retransmissionStartTime;
  
  // 检查当前帧的视口块是否都已下载
  const currentFrameData = allFiles.find(f => f.frameNumber === frameNumber);
  if (currentFrameData) {
    for (const chunkId of viewportChunks) {
      const block = currentFrameData.blocks.find(b => b.blockId === chunkId);
      if (block) {
        // 检查是否有足够质量的块
        const hasBase = block.files.some(f => f.qualityLevel === 3);
        const hasEnhancement = enhancementDownloadedFrames.has(frameNumber) && 
                              enhancementDownloadedFrames.get(frameNumber)[chunkId] < 3;
        
        if (!hasBase || hasEnhancement) {
          missingChunks.push(chunkId);
          needsRetransmission = true;
        }
      }
    }
  }
  
  // 如果需要重传，模拟实际的网络请求时间
  if (needsRetransmission) {
    // 模拟网络请求延迟（这里可以集成真实的网络请求）
    const simulatedNetworkDelay = simulateNetworkRequest(missingChunks, frameNumber);
    interactionRecord.retransmissionEndTime = performance.now() + simulatedNetworkDelay;
  } else {
    interactionRecord.retransmissionEndTime = performance.now();
  }
  
  interactionRecord.needsRetransmission = needsRetransmission;
  interactionRecord.missingChunks = missingChunks;
  
  console.log(`[实时测量] 重传检查完成: ${needsRetransmission ? '需要重传' : '无需重传'}, 缺失块: [${missingChunks.join(', ')}]`);
  
  return { needsRetransmission, missingChunks };
}

// 模拟网络请求（基于实际带宽和块大小计算）
function simulateNetworkRequest(missingChunks, frameNumber) {
  // 获取当前网络带宽（Mbps）
  const currentBandwidth = globalState.bandwidth * 8; 
  
  // 每块大小（KB）
  const chunkSizeKB = 120;
  
  // 计算总数据量（bits）
  const totalDataKB = missingChunks.length * chunkSizeKB;
  const totalDataBits = totalDataKB * 1024 * 8; // 转换为bits
  
  // 带宽转换为bits/second
  const bandwidthBitsPerSecond = currentBandwidth * 1000000; // Mbps转bits/second
  
  // 计算理论传输时间（秒）
  const transmissionTimeSeconds = totalDataBits / bandwidthBitsPerSecond;
  
  // 转换为毫秒
  const transmissionTimeMs = transmissionTimeSeconds * 1000;
  
  // 添加网络开销（TCP握手、HTTP头部等，约5-10ms）
  const networkOverhead = 5 + Math.random() * 5; // 5-10ms随机开销
  
  // 添加网络抖动（±5%）
  const networkJitter = (Math.random() - 0.5) * transmissionTimeMs * 0.1; // ±5%抖动
  
  // 最终延迟
  const finalDelay = Math.max(10, transmissionTimeMs + networkOverhead + networkJitter); // 最小10ms
  
  console.log(`[实时网络] 带宽${currentBandwidth}Mbps - 计算延迟: ${finalDelay.toFixed(2)}ms (${missingChunks.length}个块, 总数据${totalDataKB}KB, 理论传输${transmissionTimeMs.toFixed(2)}ms + 开销${networkOverhead.toFixed(1)}ms + 抖动${networkJitter.toFixed(1)}ms)`);
  
  // 使用真实的异步延迟来模拟网络请求
  setTimeout(() => {
    if (currentInteractionRecord && currentInteractionRecord.interactionId === currentInteractionId) {
      currentInteractionRecord.retransmissionEndTime = performance.now();
      const actualDelay = currentInteractionRecord.retransmissionEndTime - currentInteractionRecord.retransmissionStartTime;
      console.log(`[实时网络] 网络请求完成，实际延迟: ${actualDelay.toFixed(2)}ms`);
    }
  }, finalDelay);
  
  return finalDelay;
}

// 真实的网络请求测量（可选，用于更精确的测量）
async function measureRealNetworkRequest(missingChunks, frameNumber) {
  if (missingChunks.length === 0) return 0;
  
  const startTime = performance.now();
  
  try {
    // 尝试下载一个小的测试文件来测量实际网络延迟
    const testUrl = "https://localhost/drc_show/source/1/redandblack_vox10_1450.drc";
    const response = await fetch(testUrl, { 
      method: 'HEAD', // 只获取头部信息，减少传输量
      cache: 'no-cache'
    });
    
    const endTime = performance.now();
    const actualNetworkDelay = endTime - startTime;
    
    console.log(`[真实网络] 实际网络延迟测量: ${actualNetworkDelay.toFixed(2)}ms`);
    
    // 基于实际网络延迟和缺失块数量计算总延迟
    const perChunkDelay = actualNetworkDelay * 0.1; // 每个块额外10%的延迟
    const totalDelay = actualNetworkDelay + (missingChunks.length * perChunkDelay);
    
    return totalDelay;
  } catch (error) {
    console.log(`[真实网络] 网络测量失败，使用模拟延迟: ${error.message}`);
    // 如果真实测量失败，回退到模拟延迟
    return simulateNetworkRequest(missingChunks, frameNumber);
  }
}

// 开始测量渲染时间
function startRenderMeasurement() {
  if (currentInteractionRecord) {
    currentInteractionRecord.renderStartTime = performance.now();
  }
}

// 结束测量渲染时间
function endRenderMeasurement() {
  if (currentInteractionRecord) {
    currentInteractionRecord.renderEndTime = performance.now();
    currentInteractionRecord.frameDisplayTime = performance.now();
    
    // 完成延迟计算
    currentInteractionRecord.completeDelay();
    
    const shownDecodeDelay = currentInteractionRecord.decodeDelay > 0 ? currentInteractionRecord.decodeDelay : 0.01;
    console.log(`[交互] 第${currentInteractionRecord.interactionId}次 | 交互延迟: ${currentInteractionRecord.totalDelay.toFixed(2)}ms | 渲染: ${currentInteractionRecord.renderDelay.toFixed(2)}ms | 网络: ${currentInteractionRecord.networkDelay.toFixed(2)}ms | 解码: ${shownDecodeDelay.toFixed(2)}ms | 播放: ${currentInteractionRecord.playbackDelay.toFixed(2)}ms`);
    
    // 清除当前交互记录
    currentInteractionRecord = null;
  }
}

// 显示交互提示
function showInteractionNotification(interactionId, frameNumber, cameraPosition) {
  // 移除之前的提示
  const existingNotification = document.getElementById('interaction-notification');
  if (existingNotification) {
    existingNotification.remove();
  }
  
  // 创建交互提示
  const notification = document.createElement('div');
  notification.id = 'interaction-notification';
  notification.style.position = 'fixed';
  notification.style.top = '20px';
  notification.style.right = '20px';
  notification.style.backgroundColor = 'rgba(59, 130, 246, 0.95)';
  notification.style.color = '#ffffff';
  notification.style.padding = '15px 20px';
  notification.style.borderRadius = '10px';
  notification.style.fontSize = '14px';
  notification.style.fontWeight = 'bold';
  notification.style.zIndex = '9999';
  notification.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
  notification.style.border = '2px solid #3b82f6';
  notification.style.fontFamily = 'Arial, sans-serif';
  notification.style.minWidth = '250px';
  notification.style.textAlign = 'center';
  
  // 添加动画效果
  notification.style.transform = 'translateX(100%)';
  notification.style.transition = 'transform 0.3s ease-out';
  
  // 设置内容
  notification.innerHTML = `
    <div style="margin-bottom: 8px;">
      <span style="font-size: 16px;">🔄 自动交互 #${interactionId}</span>
    </div>
    <div style="font-size: 12px; opacity: 0.9;">
      帧 ${frameNumber} | 相机: (${cameraPosition.x.toFixed(1)}, ${cameraPosition.y.toFixed(1)}, ${cameraPosition.z.toFixed(1)})
    </div>
  `;
  
  // 添加到页面
  document.body.appendChild(notification);
  
  // 触发动画
  setTimeout(() => {
    notification.style.transform = 'translateX(0)';
  }, 10);
  
  // 3秒后自动消失
  setTimeout(() => {
    if (notification.parentNode) {
      notification.style.transform = 'translateX(100%)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.remove();
        }
      }, 300);
    }
  }, 3000);
}

// 分析点云帧的块分布
function analyzePointCloudChunks(geometry, frameNumber) {
  const { chunks, boundingBox } = splitPointCloudIntoChunks(geometry);

  // 统计每个块的点数
  const chunkStats = {};
  CHUNK_NAMES.forEach((name) => {
    chunkStats[name] = chunks[name].positions.length / 3; // 除以3因为每个点有3个坐标
  });

  // 每5帧（一个chunk）进行一次视口预测
  // 当渲染到chunk的最后一帧时触发预测
  if ((frameNumber + 1) % FRAMES_PER_CHUNK === 0) {
    // 结合视口预测分析未来帧的视口变化
    getLatestPrediction()
      .then((prediction) => {
        if (prediction && prediction.predictions.length > 0) {
          // 分析预测的10帧中每一帧的视口范围
          // 预测的是下一个chunk和再下一个chunk
          const currentChunkNumber =
            Math.floor((frameNumber - FRAME_START) / FRAMES_PER_CHUNK) + 1;
          const nextChunkStart = frameNumber + 1; // 下一个chunk的起始帧

          // 检查是否超出总chunk数
          const totalChunks = Math.ceil(allFiles.length / FRAMES_PER_CHUNK);

          if (currentChunkNumber + 1 <= totalChunks) {
            analyzePredictedFramesViewport(
              prediction,
              boundingBox,
              nextChunkStart,
              currentChunkNumber
            );
          }
        }
      })
      .catch((error) => {
        console.error("[视口预测] 获取预测结果失败:", error);
      });
  }

  return {
    chunks,
    boundingBox,
    viewportChunks: [], // 不检测当前帧的视口范围
    chunkStats,
  };
}

// 预测未来帧的视口范围
function predictFutureViewportChunks(predictedCameraPosition, boundingBox) {
  const { visibleChunks } = detectViewportChunks(
    predictedCameraPosition,
    boundingBox
  );
  return visibleChunks;
}

// 分析预测的视口变化
function analyzeViewportPrediction(
  currentViewportChunks,
  predictedViewportChunks,
  frameNumber
) {
  const newChunks = predictedViewportChunks.filter(
    (chunk) => !currentViewportChunks.includes(chunk)
  );
  const removedChunks = currentViewportChunks.filter(
    (chunk) => !predictedViewportChunks.includes(chunk)
  );

  return {
    newChunks,
    removedChunks,
  };
}

// 分析预测帧的视口范围，按chunk分组并计算平均值
function analyzePredictedFramesViewport(
  prediction,
  boundingBox,
  nextChunkStart,
  currentChunkNumber
) {
  if (
    !prediction ||
    !prediction.predictions ||
    prediction.predictions.length === 0
  ) {
    return;
  }

  // 预测的是下一个chunk和再下一个chunk
  const nextChunkNumber = currentChunkNumber + 1;

  // 将预测的10帧按chunk分组（每5帧一个chunk）
  const chunkPredictions = [];
  for (let chunkIndex = 0; chunkIndex < PREDICT_CHUNKS; chunkIndex++) {
    const startFrameIndex = chunkIndex * FRAMES_PER_CHUNK;
    const endFrameIndex = startFrameIndex + FRAMES_PER_CHUNK;
    const chunkFrames = prediction.predictions.slice(
      startFrameIndex,
      endFrameIndex
    );

    // 计算该chunk的平均摄像头位置
    const avgX =
      chunkFrames.reduce((sum, pos) => sum + pos.x, 0) / chunkFrames.length;
    const avgY =
      chunkFrames.reduce((sum, pos) => sum + pos.y, 0) / chunkFrames.length;
    const avgZ =
      chunkFrames.reduce((sum, pos) => sum + pos.z, 0) / chunkFrames.length;
    const avgPosition = new THREE.Vector3(avgX, avgY, avgZ);

    // 基于平均位置计算该chunk的视口范围
    const { visibleChunks } = detectViewportChunks(avgPosition, boundingBox);
    const viewportChunkNumbers = visibleChunks.map(
      (chunk) => CHUNK_NUMBER_MAP[chunk]
    );

    const predictedChunkNumber = nextChunkNumber + chunkIndex;

    // 检查是否已经预测过这个chunk
    if (!predictedChunks.has(predictedChunkNumber)) {
      predictedChunks.add(predictedChunkNumber);

      chunkPredictions.push({
        chunkIndex: chunkIndex + 1,
        avgPosition,
        viewportChunks: viewportChunkNumbers,
        frameRange: [
          nextChunkStart + startFrameIndex,
          nextChunkStart + endFrameIndex - 1,
        ],
      });
    }
  }

  // 保存预测结果到历史记录
  if (chunkPredictions.length > 0) {
    const timestamp = Date.now();
    const predictionResult = new ViewportPredictionResult(
      timestamp,
      currentChunkNumber,
      chunkPredictions
    );

    // 添加到历史记录
    viewportPredictionHistory.push(predictionResult);

    // 保持最多10组数据
    if (viewportPredictionHistory.length > MAX_VIEWPORT_PREDICTIONS) {
      viewportPredictionHistory.shift();
    }

    if (!globalState.viewportPredictions) {
      globalState.viewportPredictions = [];
    }
    globalState.viewportPredictions.push({
      timestamp,
      currentChunkNumber,
      predictions: chunkPredictions,
      stats: predictionResult.getStats(),
    });

    // 保持全局状态中的预测记录也在10组以内
    if (globalState.viewportPredictions.length > MAX_VIEWPORT_PREDICTIONS) {
      globalState.viewportPredictions.shift();
    }
  }

  return chunkPredictions;
}

const loader = new DRACOLoader();
loader.setDecoderPath(
  "https://www.gstatic.com/draco/versioned/decoders/1.5.6/"
);
loader.setDecoderConfig({ type: "js" });
loader.preload();
let currentMesh = null;
let frameCount_fps = 0;
let lastTime = Date.now();
let currentFPS = 0;
// ABR 相关全局变量
let currentQualityLevel = 0;
let bufferLevel = 0;
let abrIntervalId = null;
let targetQualityLevel = 3; // 初始只使用base质量，避免初始下载过多
let lastQualityChange = 0; // 记录上次质量变化的时间戳
let qualityChangePending = false; // 标记是否有质量变化待处理
let abrDecisionTime = 0; // 记录ABR决策的时间戳
let abrQualityByChunk = {}; // 记录每个chunk的ABR决策质量，例如 {1:3, 2:2, 3:1}

// ====== 双下载系统相关变量 ======
let isBaseDownloading = true; // 基础下载状态
let isEnhancementDownloading = false; // 增强下载状态
let baseDownloadQueue = []; // 基础下载队列
let enhancementDownloadQueue = []; // 增强下载队列
let baseDownloadIndex = 0; // 基础下载索引
let enhancementDownloadIndex = 0; // 增强下载索引
let baseDownloadedFrames = new Set(); // 已下载base的帧号
let enhancementDownloadedFrames = new Map(); // 已下载增强层的帧号映射 {frameNumber: {blockId: qualityLevel}}

// ====== 基础下载逻辑 ======
// 负责下载所有帧的所有块的base文件
async function baseDownloadLoop() {


  while (isBaseDownloading && baseDownloadIndex < allFiles.length) {
    const frameData = allFiles[baseDownloadIndex];
    if (!frameData) {
      console.log(`[基础下载] 帧数据不存在，索引: ${baseDownloadIndex}`);
      baseDownloadIndex++;
      continue;
    }
    const frameNumber = frameData.frameNumber;

    // 如果该帧的base已经下载过，跳过
    if (baseDownloadedFrames.has(frameNumber)) {
      baseDownloadIndex++;
      continue;
    }

    try {
      const frameBlocks = [];

      // 下载当前帧的所有8个块的base文件
      for (
        let blockIndex = 0;
        blockIndex < frameData.blocks.length;
        blockIndex++
      ) {
        const block = frameData.blocks[blockIndex];
        const blockId = block.blockId;

        // 只下载base文件
        const baseFile = block.files.find((f) => f.qualityLevel === 3);
        if (!baseFile) {
          continue;
        }

        try {
          const blockGeometry = await loadDracoGeometry(baseFile.url);

          frameBlocks.push({
            blockId,
            geometry: blockGeometry,
            quality: 3, // base质量
            frameNumber,
          });


        } catch (e) {
          console.error(
            `[基础下载] 帧${frameNumber} 块${blockId} base文件下载失败:`,
            e
          );
          continue;
        }
      }

      // 将所有base块合并为一个完整的几何体
      if (frameBlocks.length > 0) {
        const combinedGeometry = mergeAllBlocks(frameBlocks);

        baseDownloadQueue.push({
          geometry: combinedGeometry,
          meta: { number: frameNumber },
          quality: 3,
          blocks: frameBlocks,
          isBaseOnly: true,
        });

        // 标记该帧的base已下载
        baseDownloadedFrames.add(frameNumber);

        // 更新加载进度
        loadingProgress = baseDownloadQueue.length;
        updateLoadingProgress();


      }

      baseDownloadIndex++;
    } catch (e) {
      console.error(`[基础下载] 帧${frameNumber} 下载失败:`, e);
      baseDownloadIndex++;
      
      // 如果连续错误太多，提前结束基础下载
      if (baseDownloadIndex > allFiles.length * 0.8) {
        console.log(`[基础下载] 错误过多，提前结束基础下载`);
        isBaseDownloading = false;
        break;
      }
    }
  }


  isBaseDownloading = false;
}

// ====== 增强下载逻辑 ======
// 负责根据ABR算法和视口预测下载delta1和delta2文件
async function enhancementDownloadLoop() {
  console.log("[增强下载] 等待渲染1450帧后启动...");

  // 等待渲染到1450帧后才启动增强下载
  while (
    isEnhancementDownloading &&
    (globalState.currentFrameNumber || FRAME_START) < FRAME_START
  ) {
    await sleep(10);
  }

  console.log("[增强下载] 开始根据ABR和视口预测下载增强层...");

  while (
    isEnhancementDownloading &&
    enhancementDownloadIndex < allFiles.length
  ) {
    // 与渲染进度对齐：增强至少领先当前渲染一个chunk
    const currentRenderedFrame = globalState.currentFrameNumber || FRAME_START;
    const currentChunkIndex =
      Math.floor((currentRenderedFrame - FRAME_START) / FRAMES_PER_CHUNK) + 1;
    const nextChunkStartFrame =
      FRAME_START + currentChunkIndex * FRAMES_PER_CHUNK; // 下一个chunk的起始帧

    // 增强从chunk3开始：chunk3起始帧
    const chunk3StartFrame = FRAME_START + 2 * FRAMES_PER_CHUNK;

    // 修改：提前启动增强下载，当渲染到chunk2时就开始下载chunk3的增强层
    // 最小增强帧：至少下一个chunk的起始帧，且不小于chunk3起始帧
    const minEnhFrame = Math.max(nextChunkStartFrame, chunk3StartFrame);
    const minEnhIndex = Math.max(0, minEnhFrame - FRAME_START);

    if (enhancementDownloadIndex < minEnhIndex) {
      enhancementDownloadIndex = minEnhIndex;
    }

    const frameData = allFiles[enhancementDownloadIndex];
    if (!frameData) {
      console.log(`[增强下载] 帧数据不存在，索引: ${enhancementDownloadIndex}`);
      enhancementDownloadIndex++;
      continue;
    }
    const frameNumber = frameData.frameNumber;

    // 仅限制下界：必须不早于minEnhFrame
    if (frameNumber < minEnhFrame) {
      enhancementDownloadIndex = minEnhIndex;
      continue;
    }

    // 仅下载预测窗口内的帧（从下一个chunk开始，跨度为PREDICT_CHUNKS个chunk）
    const windowEndFrame =
      nextChunkStartFrame + PREDICT_CHUNKS * FRAMES_PER_CHUNK - 1;

    if (frameNumber > windowEndFrame) {
      // 等待渲染推进或预测窗口滚动
      await sleep(5); // 从10ms减少到5ms
      continue;
    }

    // 检查该帧是否已经下载了base
    if (!baseDownloadedFrames.has(frameNumber)) {
      await sleep(25); // 从50ms减少到25ms
      continue;
    }

    // 计算当前帧属于哪个chunk
    const currentChunkNumber =
      Math.floor((frameNumber - FRAME_START) / FRAMES_PER_CHUNK) + 1;

    // 跳过chunk1和chunk2（增强从chunk3开始）
    if (currentChunkNumber < 3) {
      enhancementDownloadIndex++;
      continue;
    }

    // 从chunk3开始需要等待视口预测结果
    let hasViewportPrediction = false;
    let viewportChunks = [];

    // 查找包含当前chunk的预测结果 - 优化：只检查最新的预测结果
    if (viewportPredictionHistory.length > 0) {
      const latestPrediction = viewportPredictionHistory[viewportPredictionHistory.length - 1];
      for (const pred of latestPrediction.predictions) {
        const predictedChunkNumber = latestPrediction.currentChunkNumber + pred.chunkIndex;
        if (predictedChunkNumber === currentChunkNumber) {
          if (frameNumber >= pred.frameRange[0] && frameNumber <= pred.frameRange[1]) {
            hasViewportPrediction = true;
            viewportChunks = pred.viewportChunks;
            break;
          }
        }
      }
    }

    // 如果没有视口预测结果，等待直到有结果
    if (!hasViewportPrediction) {
      console.log(
        `[增强下载] 帧${frameNumber} (Chunk${currentChunkNumber}) 等待视口预测结果...`
      );
      await sleep(5); // 从10ms减少到5ms
      continue;
    }

    console.log(
      `[增强下载] 帧${frameNumber} (Chunk${currentChunkNumber}) 获取到视口预测结果: [${viewportChunks.join(
        ", "
      )}]`
    );

    // 检查该帧是否已经下载了足够的增强层
    const currentEnhancement =
      enhancementDownloadedFrames.get(frameNumber) || {};
    const currentQuality = Math.min(...Object.values(currentEnhancement), 3);

    // 根据ABR决策和视口预测决定是否需要下载增强层
    let targetQuality = 3; // 默认base质量
    if (targetQualityLevel === 2 && currentQuality > 2) {
      targetQuality = 2; // 需要delta1
    } else if (targetQualityLevel === 1 && currentQuality > 1) {
      targetQuality = 1; // 需要delta2
    }

    // 如果不需要更高质量，跳过
    if (targetQuality >= currentQuality) {
      enhancementDownloadIndex++;
      continue;
    }

          try {
        const enhancementBlocks = [];

        // 收集需要下载的增强层信息
        const downloadTasks = [];
        
        // 只对视口预测中可见的块下载增强层
        for (
          let blockIndex = 0;
          blockIndex < frameData.blocks.length;
          blockIndex++
        ) {
          const block = frameData.blocks[blockIndex];
          const blockId = block.blockId;

          // 只对可见块下载增强层
          if (!viewportChunks.includes(blockId)) {
            continue;
          }
          const blockCurrentQuality = currentEnhancement[blockId] || 3;
          let enhancementFile = null;
          let newQuality = blockCurrentQuality;

          if (targetQuality === 2 && blockCurrentQuality > 2) {
            // 需要delta1
            enhancementFile = block.files.find((f) => f.qualityLevel === 2);
            newQuality = 2;
          } else if (targetQuality === 1 && blockCurrentQuality > 1) {
            // 需要delta2
            enhancementFile = block.files.find((f) => f.qualityLevel === 1);
            newQuality = 1;
          }

          if (enhancementFile) {
            // 创建下载任务
            downloadTasks.push({
              blockId,
              enhancementFile,
              newQuality,
              enhancementType: newQuality === 2 ? "delta1" : "delta2",
            });
          }
        }

        // 并行下载所有增强层
        if (downloadTasks.length > 0) {
          const downloadPromises = downloadTasks.map(async (task) => {
            try {
              const enhancementGeometry = await loadDracoGeometry(task.enhancementFile.url);
              return {
                blockId: task.blockId,
                geometry: enhancementGeometry,
                quality: task.newQuality,
                frameNumber,
                enhancementType: task.enhancementType,
              };
            } catch (e) {
              console.error(
                `[增强下载] 帧${frameNumber} 块${task.blockId} 增强层下载失败:`,
                e
              );
              return null;
            }
          });

          const downloadedResults = await Promise.all(downloadPromises);
          
          // 过滤掉下载失败的块
          enhancementBlocks.push(...downloadedResults.filter(result => result !== null));
        }
      if (enhancementBlocks.length > 0) {
        enhancementDownloadedFrames.set(frameNumber, {
          ...currentEnhancement,
          ...Object.fromEntries(
            enhancementBlocks.map((block) => [block.blockId, block.quality])
          ),
        });
        const upgraded = tryUpgradeQueuedFrameWithEnhancement(
          frameNumber,
          enhancementBlocks
        );
        if (!upgraded) {
          enhancementDownloadQueue.push({
            frameNumber,
            blocks: enhancementBlocks,
            targetQuality,
          });
          
        } else {
        }
      }

      enhancementDownloadIndex++;
    } catch (e) {
      console.error(`[增强下载] 帧${frameNumber} 增强层下载失败:`, e);
      enhancementDownloadIndex++;
      
      // 如果连续错误太多，提前结束增强下载
      if (enhancementDownloadIndex > allFiles.length * 0.8) {
        console.log(`[增强下载] 错误过多，提前结束增强下载`);
        isEnhancementDownloading = false;
        break;
      }
    }
  }

  console.log("[增强下载] 增强下载完成");
  isEnhancementDownloading = false;
}

// ====== 合并下载结果 ======
// 将基础下载和增强下载的结果合并到渲染队列
function mergeDownloadResults() {
  while (baseDownloadQueue.length > 0) {
    const baseFrame = baseDownloadQueue.shift();

    // 查找对应的增强层信息
    const enhancementInfo = enhancementDownloadQueue.find(
      (e) => e.frameNumber === baseFrame.meta.number
    );

    if (enhancementInfo) {
      // 合并增强层到基础几何体
      const enhancedGeometry = mergeEnhancementToBase(
        baseFrame.geometry,
        enhancementInfo.blocks
      );
      const enhancedQuality = Math.min(
        ...enhancementInfo.blocks.map((b) => b.quality)
      );

      bufferQueue.push({
        geometry: enhancedGeometry,
        meta: baseFrame.meta,
        quality: enhancedQuality,
        blocks: baseFrame.blocks.concat(enhancementInfo.blocks),
        isEnhanced: true,
        isBaseOnly: false,
      });

      // 从增强队列中移除已处理的项
      const index = enhancementDownloadQueue.findIndex(
        (e) => e.frameNumber === baseFrame.meta.number
      );
      if (index > -1) {
        enhancementDownloadQueue.splice(index, 1);
      }

      console.log(`[合并] 帧${baseFrame.meta.number} 增强层合并完成，质量等级: ${enhancedQuality}`);
      
    } else {
      // 只有基础层
      bufferQueue.push(baseFrame);
      
    }

    // 更新缓冲区使用率
    globalState.bufferUsageRate = (bufferQueue.length / MAX_BUFFER_SIZE) * 100;
  }
}

// 将增强层合并到基础几何体
function mergeEnhancementToBase(baseGeometry, enhancementBlocks) {
  if (enhancementBlocks.length === 0) {
    return baseGeometry;
  }

  // 创建增强几何体的副本
  let enhancedGeometry = baseGeometry.clone();

  // 逐个合并增强层
  for (const enhancementBlock of enhancementBlocks) {
    enhancedGeometry = mergeGeometries(
      enhancedGeometry,
      enhancementBlock.geometry
    );
  }

  return enhancedGeometry;
}

// 尝试在渲染缓冲队列中升级指定帧
function tryUpgradeQueuedFrameWithEnhancement(frameNumber, enhancementBlocks) {
  for (let i = 0; i < bufferQueue.length; i++) {
    const item = bufferQueue[i];
    if (item && item.meta && item.meta.number === frameNumber) {
      const upgradedGeometry = mergeEnhancementToBase(
        item.geometry,
        enhancementBlocks
      );
      const enhancedQuality = Math.min(
        item.quality || 3,
        ...enhancementBlocks.map((b) => b.quality)
      );
      const newBlocks = (item.blocks || []).concat(enhancementBlocks);
      bufferQueue[i] = {
        ...item,
        geometry: upgradedGeometry,
        quality: enhancedQuality,
        blocks: newBlocks,
        isEnhanced: true,
        isBaseOnly: false,
      };
      
      return true;
    }
  }
  return false;
}

// ====== 修改后的主下载逻辑 ======
// 启动双下载系统
async function startDualDownloadSystem() {


  // 启动基础下载
  baseDownloadLoop();

  // 等待基础下载完成一定数量后启动增强下载
  const initialBaseFrames = INITIAL_CHUNKS * FRAMES_PER_CHUNK;

  while (baseDownloadQueue.length < initialBaseFrames && isBaseDownloading) {
    await sleep(25); // 从50ms减少到25ms
  }

  // 等待渲染到1450帧后才启动增强下载
  while (
    (globalState.currentFrameNumber || FRAME_START) < FRAME_START &&
    isBaseDownloading
  ) {
    await sleep(25); // 从50ms减少到25ms
  }

  console.log("[双下载系统] 检测到渲染1450帧，启动增强下载...");
  isEnhancementDownloading = true;
  enhancementDownloadLoop();

  // 修改：减少合并间隔，确保增强层能及时与base层合并
  setInterval(() => {
    if (baseDownloadQueue.length > 0) {
      mergeDownloadResults();
    }
  }, 10); // 从20ms减少到10ms
}

// ====== 修改原有的downloadLoop函数 ======
// 保留原有函数名以保持兼容性，但内部调用新的双下载系统
async function downloadLoop() {
  await startDualDownloadSystem();
}

// ABR状态管理函数
function updateABRQuality(newQualityLevel, chunkIndex, reason) {
  if (newQualityLevel !== targetQualityLevel) {
    const oldQuality = targetQualityLevel;
    targetQualityLevel = newQualityLevel;
    lastQualityChange = Date.now();
    qualityChangePending = true;

    // 立即更新全局状态（展示层按每chunk ABR决策显示，仍保留全局目标）
    // 注意：这里应该显示当前chunk的质量等级，而不是全局目标质量等级
    globalState.currentQualityLevel = newQualityLevel;

    console.log(
      `[ABR质量切换] Chunk${chunkIndex} 质量等级从${oldQuality}切换到${targetQualityLevel}，原因: ${reason}`
    );

    // 记录质量变化统计
    if (!globalState.qualityChanges) {
      globalState.qualityChanges = [];
    }
    globalState.qualityChanges.push({
      chunkIndex,
      fromQuality: oldQuality,
      toQuality: targetQualityLevel,
      timestamp: Date.now(),
      reason,
    });
  }

  // 无论是否与全局目标相同，都记录当前chunk的ABR决策质量
  abrQualityByChunk[chunkIndex] = newQualityLevel;
  globalState.abrChunkQualityByChunk = abrQualityByChunk;
}

// 获取当前ABR状态
function getABRStatus() {
  return {
    currentQuality: targetQualityLevel,
    lastChange: lastQualityChange,
    pendingChange: qualityChangePending,
    bufferUsage: globalState.bufferUsageRate,
    bandwidth: globalState.bandwidth,
  };
}

// 导出ABR相关函数，方便外部监控
export function getABRStatus_export() {
  return getABRStatus();
}

// 获取质量变化历史
export function getQualityChangeHistory() {
  return globalState.qualityChanges || [];
}

// 重置ABR状态（用于重新开始播放）
export function resetABRState() {
  targetQualityLevel = 3; // 重置为base质量
  lastQualityChange = 0;
  qualityChangePending = false;
  abrDecisionTime = 0;
  if (globalState.qualityChanges) {
    globalState.qualityChanges = [];
  }

  // 重置chunk质量记录
  abrQualityByChunk = {};
  globalState.abrChunkQualityByChunk = abrQualityByChunk;

  // 重置全局状态中的质量等级为chunk质量等级
  const initialChunkQuality = getCurrentChunkQualityLevel(FRAME_START);
  globalState.currentQualityLevel = initialChunkQuality;

  // 重置双下载系统状态
  resetDualDownloadSystem();

  // 重置交互延迟历史记录
  resetInteractionDelayHistory();
}

// 获取当前渲染的帧号
export function getCurrentFrameNumber() {
  return globalState.currentFrameNumber || 0;
}

// 获取渲染状态信息
export function getRenderStatus() {
  const dualStatus = getDualDownloadStatus();

  return {
    currentFrame: globalState.currentFrameNumber || 0,
    qualityLevel: globalState.currentQualityLevel || 0,
    bufferUsage: globalState.bufferUsageRate || 0,
    fps: globalState.fps || 0,
    isRendering: isRendering,
    isBaseDownloading: dualStatus.baseDownloading,
    isEnhancementDownloading: dualStatus.enhancementDownloading,
    baseDownloadProgress: getBaseDownloadProgress().toFixed(1) + "%",
    enhancementDownloadProgress:
      getEnhancementDownloadProgress().toFixed(1) + "%",
    baseDownloadedFrames: dualStatus.baseDownloadedFramesCount,
    enhancementDownloadedFrames: dualStatus.enhancementDownloadedFramesCount,
    waitingViewportPredictionChunks: dualStatus.waitingViewportPredictionChunks,
    hasReachedStartFrame: dualStatus.hasReachedStartFrame,
    startFrame: FRAME_START,
  };
}

// 获取ABR同步状态
export function getABRSyncStatus() {
  const currentRenderedFrame = globalState.currentFrameNumber || FRAME_START;
  const expectedChunkIndex =
    Math.floor((currentRenderedFrame - FRAME_START) / FRAMES_PER_CHUNK) + 1;
  const chunkStartFrame =
    FRAME_START + (expectedChunkIndex - 1) * FRAMES_PER_CHUNK;
  const chunkEndFrame = chunkStartFrame + FRAMES_PER_CHUNK - 1;

  return {
    currentFrame: currentRenderedFrame,
    expectedChunk: expectedChunkIndex,
    chunkFrameRange: [chunkStartFrame, chunkEndFrame],
    isInSync:
      currentRenderedFrame >= chunkStartFrame &&
      currentRenderedFrame <= chunkEndFrame,
    totalChunks: Math.ceil(allFiles.length / FRAMES_PER_CHUNK),
  };
}

// ====== 视口预测相关导出函数 ======

// 获取视口预测历史记录
export function getViewportPredictionHistory() {
  return viewportPredictionHistory.map((result) => ({
    timestamp: result.timestamp,
    currentChunkNumber: result.currentChunkNumber,
    predictionId: result.predictionId,
    stats: result.getStats(),
    predictions: result.predictions,
  }));
}

// 获取最新的视口预测结果
export function getLatestViewportPrediction() {
  if (viewportPredictionHistory.length === 0) {
    return null;
  }
  const latest =
    viewportPredictionHistory[viewportPredictionHistory.length - 1];
  return {
    timestamp: latest.timestamp,
    currentChunkNumber: latest.currentChunkNumber,
    predictionId: latest.predictionId,
    stats: latest.getStats(),
    predictions: latest.predictions,
  };
}

// 获取视口预测统计信息
export function getViewportPredictionStats() {
  if (viewportPredictionHistory.length === 0) {
    return {
      totalPredictions: 0,
      averagePredictedChunks: 0,
      averagePredictedFrames: 0,
      averageViewportChunks: 0,
    };
  }

  const totalPredictions = viewportPredictionHistory.length;
  const allStats = viewportPredictionHistory.map((result) => result.getStats());

  const averagePredictedChunks =
    allStats.reduce((sum, stats) => sum + stats.totalPredictedChunks, 0) /
    totalPredictions;
  const averagePredictedFrames =
    allStats.reduce((sum, stats) => sum + stats.totalPredictedFrames, 0) /
    totalPredictions;
  const averageViewportChunks =
    allStats.reduce((sum, stats) => sum + stats.averageViewportChunks, 0) /
    totalPredictions;

  return {
    totalPredictions,
    averagePredictedChunks: averagePredictedChunks.toFixed(1),
    averagePredictedFrames: averagePredictedFrames.toFixed(1),
    averageViewportChunks: averageViewportChunks.toFixed(1),
  };
}

// 重置视口预测历史记录
export function resetViewportPredictionHistory() {
  viewportPredictionHistory = [];
  predictedChunks.clear();
  if (globalState.viewportPredictions) {
    globalState.viewportPredictions = [];
  }
  // console.log('[视口预测] 历史记录已重置');
}

// 格式化输出视口预测详细信息
export function printViewportPredictionDetails() {
  if (viewportPredictionHistory.length === 0) {
    // console.log('[视口预测] 暂无预测历史记录');
    return;
  }

  // console.log('\n=== 视口预测详细信息 ===');
  // console.log(`总预测次数: ${viewportPredictionHistory.length}`);

  const stats = getViewportPredictionStats();
  // console.log(`平均预测chunk数: ${stats.averagePredictedChunks}`);
  // console.log(`平均预测帧数: ${stats.averagePredictedFrames}`);
  // console.log(`平均视口块数: ${stats.averageViewportChunks}`);

  // console.log('\n--- 最新预测结果 ---');
  const latest = getLatestViewportPrediction();
  if (latest) {
    // console.log(`预测时间: ${new Date(latest.timestamp).toLocaleString()}`);
    // console.log(`当前Chunk: ${latest.currentChunkNumber}`);
    // console.log(`预测统计: ${JSON.stringify(latest.stats)}`);
    // latest.predictions.forEach((pred, index) => {
    //   console.log(`  Chunk${latest.currentChunkNumber + index + 1}: 帧${pred.frameRange[0]}-${pred.frameRange[1]}, 视口块[${pred.viewportChunks.join(', ')}]`);
    // });
  }

  // console.log('\n--- 历史预测记录 ---');
  // viewportPredictionHistory.forEach((result, index) => {
  //   console.log(`${index + 1}. ${result.toString()}`);
  // });
  // console.log('========================\n');
}

// 获取当前帧对应的视口预测结果
export function getViewportPredictionForFrame(frameNumber) {
  if (viewportPredictionHistory.length === 0) {
    return null;
  }

  // 计算当前帧属于哪个chunk
  const currentChunkNumber =
    Math.floor((frameNumber - FRAME_START) / FRAMES_PER_CHUNK) + 1;

  // 查找包含当前chunk的预测结果
  for (let i = viewportPredictionHistory.length - 1; i >= 0; i--) {
    const prediction = viewportPredictionHistory[i];

    // 检查预测结果中是否包含当前chunk
    for (const pred of prediction.predictions) {
      const predictedChunkNumber =
        prediction.currentChunkNumber + pred.chunkIndex;
      if (predictedChunkNumber === currentChunkNumber) {
        // 检查当前帧是否在预测的帧范围内
        if (
          frameNumber >= pred.frameRange[0] &&
          frameNumber <= pred.frameRange[1]
        ) {
          return {
            predictionId: prediction.predictionId,
            predictedChunkNumber,
            viewportChunks: pred.viewportChunks,
            frameRange: pred.frameRange,
            avgPosition: pred.avgPosition,
          };
        }
      }
    }
  }

  return null;
}

// 获取当前帧的视口块列表
export function getViewportChunksForCurrentFrame(frameNumber) {
  const prediction = getViewportPredictionForFrame(frameNumber);
  if (prediction) {
    return prediction.viewportChunks;
  }

  // 如果没有找到预测结果，返回所有块（默认行为）
  return [1, 2, 3, 4, 5, 6, 7, 8];
}

// ====== 双下载系统状态监控函数 ======

// 获取双下载系统状态
export function getDualDownloadStatus() {
  const waitingChunks = getWaitingViewportPredictionChunks();

  return {
    baseDownloading: isBaseDownloading,
    enhancementDownloading: isEnhancementDownloading,
    baseDownloadQueueLength: baseDownloadQueue.length,
    enhancementDownloadQueueLength: enhancementDownloadQueue.length,
    baseDownloadedFramesCount: baseDownloadedFrames.size,
    enhancementDownloadedFramesCount: enhancementDownloadedFrames.size,
    baseDownloadIndex,
    enhancementDownloadIndex,
    totalFrames: allFiles.length,
    waitingViewportPredictionChunks: waitingChunks.length,
    waitingChunks: waitingChunks,
    currentRenderedFrame: globalState.currentFrameNumber || 0,
    hasReachedStartFrame: (globalState.currentFrameNumber || 0) >= FRAME_START,
  };
}

// 获取基础下载进度
export function getBaseDownloadProgress() {
  if (allFiles.length === 0) return 0;
  return (baseDownloadIndex / allFiles.length) * 100;
}

// 获取增强下载进度
export function getEnhancementDownloadProgress() {
  if (allFiles.length === 0) return 0;
  return (enhancementDownloadIndex / allFiles.length) * 100;
}

// 获取已下载增强层的帧信息
export function getEnhancementDownloadInfo() {
  const info = [];
  for (const [frameNumber, blockQuality] of enhancementDownloadedFrames) {
    const qualityLevels = Object.values(blockQuality);
    const minQuality = Math.min(...qualityLevels);
    const maxQuality = Math.max(...qualityLevels);

    info.push({
      frameNumber,
      minQuality,
      maxQuality,
      blockCount: Object.keys(blockQuality).length,
      qualityDistribution: blockQuality,
    });
  }
  return info;
}

// 重置双下载系统
export function resetDualDownloadSystem() {
  isBaseDownloading = false;
  isEnhancementDownloading = false;
  baseDownloadQueue.length = 0;
  enhancementDownloadQueue.length = 0;
  baseDownloadIndex = 0;
  enhancementDownloadIndex = 0;
  baseDownloadedFrames.clear();
  enhancementDownloadedFrames.clear();

  console.log("[双下载系统] 已重置");
}

// 获取下载统计信息
export function getDownloadStatistics() {
  const baseProgress = getBaseDownloadProgress();
  const enhancementProgress = getEnhancementDownloadProgress();
  const enhancementInfo = getEnhancementDownloadInfo();

  const totalEnhancedFrames = enhancementInfo.length;
  const avgEnhancementQuality =
    enhancementInfo.length > 0
      ? enhancementInfo.reduce((sum, info) => sum + info.minQuality, 0) /
        enhancementInfo.length
      : 3;

  return {
    baseDownloadProgress: baseProgress.toFixed(1) + "%",
    enhancementDownloadProgress: enhancementProgress.toFixed(1) + "%",
    totalEnhancedFrames,
    averageEnhancementQuality: avgEnhancementQuality.toFixed(1),
    enhancementDetails: enhancementInfo,
  };
}

const bufferQueue = [];
const MAX_BUFFER_SIZE = 150; // 20个chunk × 5帧 = 100帧，增大50%后为150帧
let nextFrameIndex = 0;
let isRendering = true;
let allFiles = [];
let allFilesByQuality = [];
let loadingProgress = 0; // 加载进度
let targetLoadingFrames = 0; // 目标加载帧数

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function loadDracoGeometry(url) {
  return new Promise((resolve, reject) => {
    loader.load(url, resolve, undefined, reject);
  });
}

// 优化的几何体合并方法 - 直接拼接所有块
function mergeAllBlocks(frameBlocks) {
  if (frameBlocks.length === 0) return null;
  if (frameBlocks.length === 1) return frameBlocks[0].geometry;

  // 预先计算总顶点数
  let totalVertices = 0;
  let hasColors = false;

  for (const block of frameBlocks) {
    const geometry = block.geometry;
    totalVertices += geometry.attributes.position.count;
    if (geometry.attributes.color) {
      hasColors = true;
    }
  }

  // 一次性分配内存
  const combinedPositions = new Float32Array(totalVertices * 3);
  const combinedColors = new Float32Array(totalVertices * 3); // 强制分配颜色，缺失时填白

  let vertexOffset = 0;
  const defaultR = 1.0,
    defaultG = 1.0,
    defaultB = 1.0;

  // 直接拼接所有块的数据
  for (const block of frameBlocks) {
    const geometry = block.geometry;
    const positions = geometry.attributes.position.array;
    const colorAttr = geometry.attributes.color
      ? geometry.attributes.color.array
      : null;
    const count = geometry.attributes.position.count;

    // 复制位置数据
    combinedPositions.set(positions, vertexOffset * 3);

    // 复制或填充颜色数据
    if (colorAttr) {
      combinedColors.set(colorAttr, vertexOffset * 3);
    } else {
      for (let i = 0; i < count; i++) {
        const off = (vertexOffset + i) * 3;
        combinedColors[off] = defaultR;
        combinedColors[off + 1] = defaultG;
        combinedColors[off + 2] = defaultB;
      }
    }

    vertexOffset += count;
  }

  // 创建合并后的几何体
  const combinedGeometry = new THREE.BufferGeometry();
  combinedGeometry.setAttribute(
    "position",
    new THREE.BufferAttribute(combinedPositions, 3)
  );
  combinedGeometry.setAttribute(
    "color",
    new THREE.BufferAttribute(combinedColors, 3)
  );
  combinedGeometry.computeVertexNormals();

  return combinedGeometry;
}

// 保留原有的mergeGeometries用于质量等级合并
function mergeGeometries(base, enhancement) {
  const basePos = base.getAttribute("position").array;
  const enhPos = enhancement.getAttribute("position").array;
  const combinedPositions = new Float32Array(basePos.length + enhPos.length);
  combinedPositions.set(basePos, 0);
  combinedPositions.set(enhPos, basePos.length);

  // 颜色处理：尽量保留已有颜色；若部分缺失则为缺失段填默认白色
  const baseColorAttr = base.getAttribute("color");
  const enhColorAttr = enhancement.getAttribute("color");
  const baseVertexCount = base.getAttribute("position").count;
  const enhVertexCount = enhancement.getAttribute("position").count;
  let combinedColors = null;

  if (baseColorAttr || enhColorAttr) {
    combinedColors = new Float32Array((baseVertexCount + enhVertexCount) * 3);
    const defaultR = 1.0,
      defaultG = 1.0,
      defaultB = 1.0;

    if (baseColorAttr) {
      combinedColors.set(baseColorAttr.array, 0);
    } else {
      // 基础几何没有颜色，为其填充白色
      for (let i = 0; i < baseVertexCount; i++) {
        const offset = i * 3;
        combinedColors[offset] = defaultR;
        combinedColors[offset + 1] = defaultG;
        combinedColors[offset + 2] = defaultB;
      }
    }

    if (enhColorAttr) {
      combinedColors.set(enhColorAttr.array, baseVertexCount * 3);
    } else {
      // 增强几何没有颜色，为其填充白色
      const start = baseVertexCount * 3;
      for (let i = 0; i < enhVertexCount; i++) {
        const offset = start + i * 3;
        combinedColors[offset] = defaultR;
        combinedColors[offset + 1] = defaultG;
        combinedColors[offset + 2] = defaultB;
      }
    }
  }

  const combinedGeometry = new THREE.BufferGeometry();
  combinedGeometry.setAttribute(
    "position",
    new THREE.BufferAttribute(combinedPositions, 3)
  );
  if (combinedColors) {
    combinedGeometry.setAttribute(
      "color",
      new THREE.BufferAttribute(combinedColors, 3)
    );
  }
  combinedGeometry.computeVertexNormals();
  return combinedGeometry;
}

function renderGeometry(geometry) {
  geometry.computeVertexNormals();
  const hasColors = !!geometry.getAttribute("color");
  const material = new THREE.PointsMaterial({
    vertexColors: hasColors,
    size: 0.1,
  });
  const newMesh = new THREE.Points(geometry, material);
  newMesh.scale.set(0.05, 0.05, 0.05);
  newMesh.position.set(-18, -25, -10);
  scene.add(newMesh);
  if (currentMesh) {
    scene.remove(currentMesh);
  }
  currentMesh = newMesh;
}

function startFPSCounter() {
  frameCount_fps = 0;
  lastTime = Date.now();
}

function updateFPSCounter() {
  frameCount_fps++;
  const now = Date.now();
  const timeDelta = now - lastTime;
  if (timeDelta >= 1000) {
    currentFPS = frameCount_fps;
    globalState.fps = currentFPS;
    frameCount_fps = 0;
    lastTime = now;
  }
}

function parseMPD(mpdXml) {
  const blockRepresentations = []; // 存储8个块的所有表示
  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(mpdXml, "application/xml");
  const adaptationSets = xmlDoc.getElementsByTagName("AdaptationSet");

  // 遍历每个AdaptationSet（对应8个块）
  for (let blockIndex = 0; blockIndex < adaptationSets.length; blockIndex++) {
    const adaptationSet = adaptationSets[blockIndex];
    const blockId = adaptationSet.getAttribute("id");
    const segmentTemplate = adaptationSet.querySelector("SegmentTemplate");
    const reps = adaptationSet.getElementsByTagName("Representation");

    const blockQualityLevels = []; // 存储当前块的3个质量等级

    // 遍历每个Representation（base, delta1, delta2）
    for (let repIndex = 0; repIndex < reps.length; repIndex++) {
      const rep = reps[repIndex];
      const id = rep.getAttribute("id");
      const bandwidth = parseInt(rep.getAttribute("bandwidth"));
      const size = parseInt(rep.getAttribute("size"));

      // 只处理base、delta1、delta2
      if (id !== "base" && id !== "delta1" && id !== "delta2") continue;

      const mediaPattern = segmentTemplate
        ? segmentTemplate.getAttribute("media")
        : "";
      const qualityFiles = [];

      // 为每个帧号生成文件路径
      for (let number = FRAME_START; number <= FRAME_END; number++) {
        const filePath = mediaPattern
          .replace("$RepresentationID$", id)
          .replace("$Number$", number);
        qualityFiles.push({
          bandwidth,
          size,
          url: filePath,
          number: number, // 添加number属性
          blockId: parseInt(blockId),
          qualityLevel: id === "base" ? 3 : id === "delta1" ? 2 : 1,
        });
      }

      blockQualityLevels.push(qualityFiles);
    }

    // 将当前块的所有质量等级添加到总列表中
    blockRepresentations.push(blockQualityLevels);
  }

  return blockRepresentations;
}

function measureBandwidth() {
  const startTime = Date.now();
  // 替换带宽测试url，使用新的分块文件结构
  const url = "https://localhost/drc_show/source/1/redandblack_vox10_1450.drc";
  return new Promise((resolve, reject) => {
    fetch(url)
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.blob();
      })
      .then((blob) => {
        const endTime = Date.now();
        const downloadTime = (endTime - startTime) / 1000; // 秒
        const fileSizeBytes = blob.size; // 字节
        const bandwidthMBps = fileSizeBytes / (downloadTime * 1024 * 1024); // MBps
        resolve(bandwidthMBps);
      })
      .catch((error) => {
        console.error(`[带宽测量] 失败: ${error.message}`);
        resolve(10); // 返回默认带宽值
      });
  });
}

// 生成所有帧文件列表（每个帧包含8个块，每个块有3个质量等级）
function generateAllFiles(blockRepresentations, qualityLevel = 0) {
  // 重新组织数据结构：按帧号组织，每个帧包含8个块的信息
  const framesByNumber = {};

  // 为每个帧号创建数据结构
  for (let frameNumber = FRAME_START; frameNumber <= FRAME_END; frameNumber++) {
    framesByNumber[frameNumber] = {
      frameNumber,
      blocks: [], // 存储8个块的信息
    };

    // 为每个块添加文件信息
    for (
      let blockIndex = 0;
      blockIndex < blockRepresentations.length;
      blockIndex++
    ) {
      const blockQualityLevels = blockRepresentations[blockIndex];
      const blockFiles = [];

      // 为当前块添加所有质量等级的文件
      for (
        let qualityIndex = 0;
        qualityIndex < blockQualityLevels.length;
        qualityIndex++
      ) {
        const qualityFiles = blockQualityLevels[qualityIndex];
        const frameFile = qualityFiles.find((f) => f.number === frameNumber);
        if (frameFile) {
          blockFiles.push(frameFile);
        }
      }

      framesByNumber[frameNumber].blocks.push({
        blockId: blockIndex + 1,
        files: blockFiles,
      });
    }
  }

  // 转换为数组格式，保持向后兼容
  const allFrames = Object.values(framesByNumber);

  return allFrames;
}

// 质量等级控制逻辑已移除，现在完全由ABR算法控制
// 质量等级在downloadLoop中根据targetQualityLevel设置

// 主入口函数，调用后开始下载和渲染
export async function playWithBuffer(blockRepresentations, qualityLevel = 0) {
  allFiles = generateAllFiles(blockRepresentations, qualityLevel);

  // 重置双下载系统状态
  nextFrameIndex = 0;
  bufferQueue.length = 0;
  baseDownloadQueue.length = 0;
  enhancementDownloadQueue.length = 0;
  baseDownloadIndex = 0;
  enhancementDownloadIndex = 0;
  baseDownloadedFrames.clear();
  enhancementDownloadedFrames.clear();

  // 设置下载状态
  isBaseDownloading = true;
  isEnhancementDownloading = false;
  isRendering = false; // 先不渲染
  currentQualityLevel = qualityLevel;
  bufferLevel = MAX_BUFFER_SIZE;

  // 设置目标加载帧数
  targetLoadingFrames = INITIAL_CHUNKS * FRAMES_PER_CHUNK;
  loadingProgress = 0;

  // 显示加载提示
  if (typeof showLoadingOverlay === "function") showLoadingOverlay();

  // 启动双下载系统
  downloadLoop();

  // 等待初始chunk填满（基于基础下载队列）
  const initialFrames = INITIAL_CHUNKS * FRAMES_PER_CHUNK;

  while (baseDownloadQueue.length < initialFrames && isBaseDownloading) {
    await sleep(25); // 从50ms减少到25ms
  }


  if (typeof hideLoadingOverlay === "function") hideLoadingOverlay();
  isRendering = true;
  renderLoop();
}

export async function fetchAndParseMPD_show(mpdUrl) {
  try {
    const response = await fetch(mpdUrl);
    const mpdXml = await response.text();
    const blockRepresentations = parseMPD(mpdXml);
    return blockRepresentations;
  } catch (error) {
    console.error("Error fetching and parsing MPD:", error);
    throw error;
  }
}

// Buffer-based ABR 控制（Chunk频率）
export async function play_control_tbb(blockRepresentations) {
  // 启动缓冲区机制
  await playWithBuffer(blockRepresentations, 0);

  // 初始化全局状态中的质量等级为chunk质量等级
  const initialChunkQuality = getCurrentChunkQualityLevel(FRAME_START);
  globalState.currentQualityLevel = initialChunkQuality;

  // 启动基于缓冲区的 ABR 逻辑定时器（每chunk评估一次）
  const FRAME_DURATION = 1 / 10; // 10fps
  bufferLevel = MAX_BUFFER_SIZE;
  let currentChunkIndex = 0;
  let framesInCurrentChunk = 0;
  const totalChunks = Math.ceil(allFiles.length / FRAMES_PER_CHUNK); // 计算总chunk数
  let bandwidth = null;
  let previousBandwidth = null;
  let lastQualityLevel = targetQualityLevel; // 记录上次的质量等级
  let lastProcessedFrame = FRAME_START; // 记录上次处理的帧号

  if (abrIntervalId) clearInterval(abrIntervalId);
  abrIntervalId = setInterval(async () => {
    framesInCurrentChunk++;

    // 获取当前实际渲染的帧号
    const currentRenderedFrame = globalState.currentFrameNumber || FRAME_START;

    // 计算当前应该处理的chunk
    const expectedChunkIndex =
      Math.floor((currentRenderedFrame - FRAME_START) / FRAMES_PER_CHUNK) + 1;

    // 每5帧（一个chunk）进行一次ABR决策，基于实际渲染的帧
    if (
      framesInCurrentChunk >= FRAMES_PER_CHUNK &&
      expectedChunkIndex > currentChunkIndex
    ) {
      currentChunkIndex = expectedChunkIndex;
      framesInCurrentChunk = 0;

      // 检查是否超出总chunk数或缓冲区为空
      if (
        currentChunkIndex > totalChunks ||
        (bufferQueue.length === 0 &&
          !isBaseDownloading &&
          !isEnhancementDownloading)
      ) {
        clearInterval(abrIntervalId);
        abrIntervalId = null;
        return;
      }

      // 每2个chunk更新一次带宽
      if (currentChunkIndex % 2 === 0) {
        previousBandwidth = bandwidth;
        bandwidth = await measureBandwidth();
        globalState.bandwidth = bandwidth;
        if (previousBandwidth) {
          const bandwidthChange =
            ((bandwidth - previousBandwidth) / previousBandwidth) * 100;
          globalState.bandwidthIncrease = bandwidthChange;
        }
      }

      // 计算缓冲区使用率（基于合并后的渲染队列）
      const bufferUsageRate = (bufferQueue.length / MAX_BUFFER_SIZE) * 100;
      bufferLevel = bufferQueue.length * FRAME_DURATION;
      globalState.bufferLevel = bufferLevel.toFixed(2);
      globalState.bufferUsageRate = bufferUsageRate;

      // 计算当前chunk对应的帧范围
      const chunkStartFrame =
        FRAME_START + (currentChunkIndex - 1) * FRAMES_PER_CHUNK;
      const chunkEndFrame = chunkStartFrame + FRAMES_PER_CHUNK - 1;

      // 使用ABR管理器进行决策
      const abrContext = {
        bufferUsageRate,
        bandwidth,
        currentQualityLevel: targetQualityLevel,
        chunkIndex: currentChunkIndex,
        previousBandwidth,
      };

      const abrDecision = abrManager.makeABRDecision(abrContext);
      let newQualityLevel = abrDecision.newQualityLevel;
      let reason = abrDecision.reason;

      // 如果ABR决策的质量等级为3（基础质量），但当前目标质量不是3，说明需要强制降低
      if (newQualityLevel === 3 && targetQualityLevel !== 3) {
        reason = `缓冲区严重不足(${bufferUsageRate.toFixed(
          1
        )}%)，强制降低到基础质量(base-line)`;
      }

      // 检查质量等级是否发生变化
      if (newQualityLevel !== lastQualityLevel) {
        updateABRQuality(newQualityLevel, currentChunkIndex, reason);
        lastQualityLevel = newQualityLevel;

        // 输出双下载系统状态
        const dualStatus = getDualDownloadStatus();
        console.log(
          `[ABR质量切换] 双下载系统状态: 基础下载${
            dualStatus.baseDownloading ? "进行中" : "已完成"
          }, 增强下载${dualStatus.enhancementDownloading ? "进行中" : "未开始"}`
        );
      }

      // 更新全局状态（使用当前chunk的质量等级）
      const currentChunkQuality =
        getCurrentChunkQualityLevel(currentRenderedFrame);
      globalState.currentQualityLevel = currentChunkQuality;
      lastProcessedFrame = currentRenderedFrame;
    }
  }, 1000 / 10); // 每帧检查一次，但每5帧做一次决策
}

// 更新加载进度
function updateLoadingProgress() {
  const progressElement = document.getElementById("loading-progress");
  const progressText = document.getElementById("loading-text");

  if (progressElement && progressText) {
    const percentage = Math.round(
      (loadingProgress / targetLoadingFrames) * 100
    );
    progressElement.style.width = `${percentage}%`;
    progressText.textContent = `正在加载缓冲区... ${percentage}%`;
  }
}

function showLoadingOverlay() {
  if (document.getElementById("custom-loading-overlay")) return;
  const overlay = document.createElement("div");
  overlay.id = "custom-loading-overlay";
  overlay.style.position = "fixed";
  overlay.style.top = "0";
  overlay.style.left = "0";
  overlay.style.width = "100vw";
  overlay.style.height = "100vh";
  overlay.style.background = "rgba(30, 41, 59, 0.85)";
  overlay.style.display = "flex";
  overlay.style.flexDirection = "column";
  overlay.style.alignItems = "center";
  overlay.style.justifyContent = "center";
  overlay.style.zIndex = "9999";

  // 动画圈
  const spinner = document.createElement("div");
  spinner.style.border = "8px solid #e5e7eb";
  spinner.style.borderTop = "8px solid #60a5fa";
  spinner.style.borderRadius = "50%";
  spinner.style.width = "70px";
  spinner.style.height = "70px";
  spinner.style.animation = "spinLoading 1s linear infinite";

  // 进度条容器
  const progressContainer = document.createElement("div");
  progressContainer.style.width = "300px";
  progressContainer.style.height = "20px";
  progressContainer.style.backgroundColor = "#374151";
  progressContainer.style.borderRadius = "10px";
  progressContainer.style.marginTop = "20px";
  progressContainer.style.overflow = "hidden";
  progressContainer.style.position = "relative";

  // 进度条
  const progressBar = document.createElement("div");
  progressBar.id = "loading-progress";
  progressBar.style.width = "0%";
  progressBar.style.height = "100%";
  progressBar.style.backgroundColor = "#60a5fa";
  progressBar.style.transition = "width 0.3s ease";
  progressBar.style.borderRadius = "10px";

  // 文字
  const text = document.createElement("div");
  text.id = "loading-text";
  text.textContent = "正在加载缓冲区... 0/100 (0%)";
  text.style.color = "#fff";
  text.style.fontSize = "1.2em";
  text.style.marginTop = "16px";
  text.style.letterSpacing = "1px";
  text.style.fontWeight = "bold";

  progressContainer.appendChild(progressBar);
  overlay.appendChild(spinner);
  overlay.appendChild(progressContainer);
  overlay.appendChild(text);
  document.body.appendChild(overlay);

  // 动画样式
  if (!document.getElementById("custom-loading-style")) {
    const style = document.createElement("style");
    style.id = "custom-loading-style";
    style.textContent = `
      @keyframes spinLoading {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    `;
    document.head.appendChild(style);
  }
}

function hideLoadingOverlay() {
  const overlay = document.getElementById("custom-loading-overlay");
  if (overlay) overlay.remove();
}

// 测试文件下载功能
export async function testFileDownload(blockRepresentations) {
  // 测试第一帧的第一个块
  const testFrame = FRAME_START;
  const testBlock = 1;

  try {
    // 生成测试文件列表
    const testFiles = generateAllFiles(blockRepresentations, 0);
    const frameData = testFiles.find((f) => f.frameNumber === testFrame);

    if (!frameData) {
      return;
    }

    // 测试第一个块
    const block = frameData.blocks.find((b) => b.blockId === testBlock);
    if (!block) {
      return;
    }

    // 尝试下载base文件
    const baseFile = block.files.find((f) => f.qualityLevel === 3);
    if (baseFile) {
      try {
        const geometry = await loadDracoGeometry(baseFile.url);
        console.log("[测试] base文件下载成功");

        // 测试增强层下载
        const delta1File = block.files.find((f) => f.qualityLevel === 2);
        if (delta1File) {
          try {
            const delta1Geometry = await loadDracoGeometry(delta1File.url);
            console.log("[测试] delta1文件下载成功");

            // 测试合并
            const mergedGeometry = mergeGeometries(geometry, delta1Geometry);
            console.log("[测试] 几何体合并成功");
          } catch (e) {
            console.error("[测试] delta1文件下载失败:", e);
          }
        }
      } catch (error) {
        console.error("[测试] base文件下载失败:", error);
      }
    }
  } catch (error) {
    console.error("[测试] 文件下载测试失败:", error);
  }
}

async function renderLoop() {
  let renderedFrameCount = 0;
  let lastRenderedFrame = 0; // 记录上次渲染的帧号

  while (isRendering) {
    if (bufferQueue.length > 0) {
      const { geometry, meta, quality, blocks, isEnhanced, isBaseOnly } =
        bufferQueue.shift();
      renderedFrameCount++;
      globalState.bufferUsageRate =
        (bufferQueue.length / MAX_BUFFER_SIZE) * 100;

      // 使用chunk质量等级而不是帧质量等级，避免快速跳动
      const chunkQualityLevel = getCurrentChunkQualityLevel(meta.number);
      globalState.currentQualityLevel = chunkQualityLevel;

      // 更新上次渲染的帧号
      if (meta.number !== lastRenderedFrame) {
        lastRenderedFrame = meta.number;
      }

      // 更新全局状态中的当前帧号（这是增强下载系统检测的关键）
      globalState.currentFrameNumber = meta.number;

      // 检查是否到达1450帧，如果是则输出日志
      if (meta.number === FRAME_START) {
        console.log(`[渲染] 到达起始帧${FRAME_START}，增强下载系统将启动`);
      }

      // 获取当前帧的视口预测结果
      const viewportPrediction = getViewportPredictionForFrame(meta.number);
      const viewportChunks = getViewportChunksForCurrentFrame(meta.number);

      // 分析块的质量等级分布
      const baseBlocks = blocks
        .filter((block) => block.quality === 3)
        .map((block) => block.blockId);
      const delta1Blocks = blocks
        .filter((block) => block.quality === 2)
        .map((block) => block.blockId);
      const delta2Blocks = blocks
        .filter((block) => block.quality === 1)
        .map((block) => block.blockId);

      // 输出渲染信息
      let qualityDescription = "";
      if (isBaseOnly) {
        qualityDescription = "仅base层";
      } else if (isEnhanced) {
        qualityDescription = quality === 2 ? "base+delta1" : "base+delta2";
      } else {
        qualityDescription =
          quality === 3
            ? "base"
            : quality === 2
            ? "base+delta1"
            : "base+delta2";
      }

      console.log(
        `[渲染] 帧${meta.number}, Chunk质量等级: ${chunkQualityLevel}, 帧实际质量: ${quality} (${qualityDescription})`
      );

      // 显示优化的块请求信息
      if (isEnhanced) {
        const viewportDelta1Blocks = delta1Blocks.filter((blockId) =>
          viewportChunks.includes(blockId)
        );
        const viewportDelta2Blocks = delta2Blocks.filter((blockId) =>
          viewportChunks.includes(blockId)
        );

        if (viewportDelta1Blocks.length > 0) {
          console.log(`  增强层delta1块: [${viewportDelta1Blocks.join(", ")}]`);
        }
        if (viewportDelta2Blocks.length > 0) {
          console.log(`  增强层delta2块: [${viewportDelta2Blocks.join(", ")}]`);
        }
      } else if (isBaseOnly) {
        console.log(`  仅基础层块: [${baseBlocks.join(", ")}]`);
      } else {
        // 兼容旧版本的输出格式
        const viewportDelta1Blocks = delta1Blocks.filter((blockId) =>
          viewportChunks.includes(blockId)
        );
        const viewportDelta2Blocks = delta2Blocks.filter((blockId) =>
          viewportChunks.includes(blockId)
        );

        if (viewportDelta1Blocks.length > 0) {
          console.log(
            `  额外请求delta1的块: [${viewportDelta1Blocks.join(", ")}]`
          );
        }
        if (viewportDelta2Blocks.length > 0) {
          console.log(
            `  额外请求delta2的块: [${viewportDelta2Blocks.join(", ")}]`
          );
        }
        if (
          baseBlocks.length > 0 &&
          viewportDelta1Blocks.length === 0 &&
          viewportDelta2Blocks.length === 0
        ) {
          console.log(`  仅使用base质量的块: [${baseBlocks.join(", ")}]`);
        }
      }

      // 开始测量渲染时间
      startRenderMeasurement();
      
      // 渲染几何体
      renderGeometry(geometry);
      
      // 结束测量渲染时间
      endRenderMeasurement();
      
      updateFPSCounter();

      // 执行点云分块分析
      analyzePointCloudChunks(geometry, meta.number);

      // 更新摄像头位置历史并执行视口预测
      updateCameraPositionHistory();

      // 检查是否需要执行自动交互（每10帧执行一次）
      if (meta.number - lastInteractionFrame >= interactionInterval) {
        performAutoInteraction(meta.number);
        lastInteractionFrame = meta.number;
      }



      await sleep(1000 / 10); // 10fps 
    } else {
      await sleep(100);
      // 如果下载和渲染都结束，停止带宽测量并显示交互延迟统计
      if (
        isBaseDownloading === false &&
        isEnhancementDownloading === false &&
        bufferQueue.length === 0 &&
        abrIntervalId
      ) {
        clearInterval(abrIntervalId);
        abrIntervalId = null;
        
        // 计算并显示平均交互延迟
        showAverageInteractionDelay();
        break;
      }
      
      // 额外的结束条件：如果当前帧号已经超过结束帧号，也显示结果
      const currentFrame = globalState.currentFrameNumber || FRAME_START;
      if (currentFrame > FRAME_END && interactionDelayHistory.length > 0) {
        console.log(`[渲染结束] 当前帧${currentFrame}已超过结束帧${FRAME_END}，显示交互延迟统计`);
        showAverageInteractionDelay();
        break;
      }
    }
  }
}

// 测试双下载系统
export function testDualDownloadSystem() {
  console.log("=== 双下载系统测试 ===");

  const status = getDualDownloadStatus();
  console.log("系统状态:", status);

  const stats = getDownloadStatistics();
  console.log("下载统计:", stats);

  const renderStatus = getRenderStatus();
  console.log("渲染状态:", renderStatus);

  console.log("=== 测试完成 ===");
}

// 检查特定chunk是否有视口预测结果
function hasViewportPredictionForChunk(chunkNumber) {
  for (let i = viewportPredictionHistory.length - 1; i >= 0; i--) {
    const prediction = viewportPredictionHistory[i];

    // 检查预测结果中是否包含指定chunk
    for (const pred of prediction.predictions) {
      const predictedChunkNumber =
        prediction.currentChunkNumber + pred.chunkIndex;
      if (predictedChunkNumber === chunkNumber) {
        return true;
      }
    }
  }
  return false;
}

// 检查特定chunk的增强层下载状态
function getChunkEnhancementStatus(chunkNumber) {
  const chunkStartFrame = FRAME_START + (chunkNumber - 1) * FRAMES_PER_CHUNK;
  const chunkEndFrame = chunkStartFrame + FRAMES_PER_CHUNK - 1;
  
  const enhancedFrames = [];
  const baseOnlyFrames = [];
  
  for (let frameNumber = chunkStartFrame; frameNumber <= chunkEndFrame; frameNumber++) {
    if (enhancementDownloadedFrames.has(frameNumber)) {
      const blockQuality = enhancementDownloadedFrames.get(frameNumber);
      const qualityLevels = Object.values(blockQuality);
      const minQuality = Math.min(...qualityLevels);
      
      enhancedFrames.push({
        frameNumber,
        minQuality,
        blockCount: Object.keys(blockQuality).length,
        qualityDistribution: blockQuality
      });
    } else if (baseDownloadedFrames.has(frameNumber)) {
      baseOnlyFrames.push(frameNumber);
    }
  }
  
  return {
    chunkNumber,
    frameRange: [chunkStartFrame, chunkEndFrame],
    totalFrames: FRAMES_PER_CHUNK,
    enhancedFrames: enhancedFrames.length,
    baseOnlyFrames: baseOnlyFrames.length,
    averageQuality: enhancedFrames.length > 0 
      ? enhancedFrames.reduce((sum, info) => sum + info.minQuality, 0) / enhancedFrames.length 
      : 3,
    enhancedFrameDetails: enhancedFrames,
    baseOnlyFrameDetails: baseOnlyFrames
  };
}

// 获取特定chunk的视口预测结果
function getViewportPredictionForChunk(chunkNumber) {
  for (let i = viewportPredictionHistory.length - 1; i >= 0; i--) {
    const prediction = viewportPredictionHistory[i];

    // 检查预测结果中是否包含指定chunk
    for (const pred of prediction.predictions) {
      const predictedChunkNumber =
        prediction.currentChunkNumber + pred.chunkIndex;
      if (predictedChunkNumber === chunkNumber) {
        return {
          predictionId: prediction.predictionId,
          predictedChunkNumber,
          viewportChunks: pred.viewportChunks,
          frameRange: pred.frameRange,
          avgPosition: pred.avgPosition,
        };
      }
    }
  }
  return null;
}

// 获取等待视口预测的chunk列表
export function getWaitingViewportPredictionChunks() {
  const waitingChunks = [];

  for (
    let frameIndex = enhancementDownloadIndex;
    frameIndex < allFiles.length;
    frameIndex++
  ) {
    const frameData = allFiles[frameIndex];
    if (!frameData) {
      continue;
    }
    const frameNumber = frameData.frameNumber;
    const chunkNumber =
      Math.floor((frameNumber - FRAME_START) / FRAMES_PER_CHUNK) + 1;

    // 只统计chunk2及以后的chunk（chunk1不需要等待视口预测）
    if (chunkNumber >= 2 && !hasViewportPredictionForChunk(chunkNumber)) {
      if (!waitingChunks.find((w) => w.chunkNumber === chunkNumber)) {
        waitingChunks.push({
          chunkNumber,
          frameRange: [
            FRAME_START + (chunkNumber - 1) * FRAMES_PER_CHUNK,
            FRAME_START + chunkNumber * FRAMES_PER_CHUNK - 1,
          ],
        });
      }
    }
  }

  return waitingChunks;
}

// 获取chunk1的默认视口块（所有块都可见）
function getChunk1DefaultViewportChunks() {
  return [1, 2, 3, 4, 5, 6, 7, 8]; // 所有8个块都可见
}

// 获取chunk1的增强下载状态
export function getChunk1EnhancementStatus() {
  const chunk1Frames = [];
  const chunk1StartFrame = FRAME_START;
  const chunk1EndFrame = FRAME_START + FRAMES_PER_CHUNK - 1;

  // 统计chunk1中已下载增强层的帧
  for (const [frameNumber, blockQuality] of enhancementDownloadedFrames) {
    if (frameNumber >= chunk1StartFrame && frameNumber <= chunk1EndFrame) {
      const qualityLevels = Object.values(blockQuality);
      const minQuality = Math.min(...qualityLevels);
      const maxQuality = Math.max(...qualityLevels);

      chunk1Frames.push({
        frameNumber,
        minQuality,
        maxQuality,
        blockCount: Object.keys(blockQuality).length,
        qualityDistribution: blockQuality,
      });
    }
  }

  return {
    chunkNumber: 1,
    frameRange: [chunk1StartFrame, chunk1EndFrame],
    totalFrames: FRAMES_PER_CHUNK,
    enhancedFrames: chunk1Frames.length,
    averageQuality:
      chunk1Frames.length > 0
        ? chunk1Frames.reduce((sum, info) => sum + info.minQuality, 0) /
          chunk1Frames.length
        : 3,
    defaultViewportChunks: getChunk1DefaultViewportChunks(),
    needsViewportPrediction: false,
  };
}

// 获取当前chunk的质量等级（基于ABR决策，而不是帧的实际渲染质量）
function getCurrentChunkQualityLevel(frameNumber) {
  const currentChunkNumber =
    Math.floor((frameNumber - FRAME_START) / FRAMES_PER_CHUNK) + 1;

  // 如果该chunk有ABR决策记录，返回决策的质量等级
  if (abrQualityByChunk[currentChunkNumber] !== undefined) {
    return abrQualityByChunk[currentChunkNumber];
  }

  // 如果没有ABR决策记录，返回默认质量等级
  return targetQualityLevel;
}

// ====== 交互延迟统计和显示函数 ======

// 计算平均交互延迟
function calculateAverageInteractionDelay() {
  if (interactionDelayHistory.length === 0) {
    return {
      totalInteractions: 0,
      averageTotalDelay: 0,
      averageRenderDelay: 0,
      averageNetworkDelay: 0,
      averageDecodeDelay: 0,
      averagePlaybackDelay: 0,
      retransmissionRate: 0,
      bufferSufficientRate: 0
    };
  }

  const totalInteractions = interactionDelayHistory.length;
  const totalDelaySum = interactionDelayHistory.reduce((sum, record) => sum + record.totalDelay, 0);
  const renderDelaySum = interactionDelayHistory.reduce((sum, record) => sum + record.renderDelay, 0);
  const networkDelaySum = interactionDelayHistory.reduce((sum, record) => sum + record.networkDelay, 0);
  const decodeDelaySum = interactionDelayHistory.reduce((sum, record) => sum + record.decodeDelay, 0);
  const playbackDelaySum = interactionDelayHistory.reduce((sum, record) => sum + record.playbackDelay, 0);
  
  const retransmissionCount = interactionDelayHistory.filter(record => record.needsRetransmission).length;
  const bufferSufficientCount = interactionDelayHistory.filter(record => record.bufferStatus.isBufferSufficient).length;

  return {
    totalInteractions,
    averageTotalDelay: totalDelaySum / totalInteractions,
    averageRenderDelay: renderDelaySum / totalInteractions,
    averageNetworkDelay: networkDelaySum / totalInteractions,
    averageDecodeDelay: decodeDelaySum / totalInteractions,
    averagePlaybackDelay: playbackDelaySum / totalInteractions,
    retransmissionRate: (retransmissionCount / totalInteractions) * 100,
    bufferSufficientRate: (bufferSufficientCount / totalInteractions) * 100
  };
}

// 显示平均交互延迟弹窗
function showAverageInteractionDelay() {
  const stats = calculateAverageInteractionDelay();
  
  if (stats.totalInteractions === 0) {
    console.log('[交互延迟] 没有记录到任何交互');
    return;
  }

  // 创建弹窗
  const modal = document.createElement('div');
  modal.style.position = 'fixed';
  modal.style.top = '0';
  modal.style.left = '0';
  modal.style.width = '100vw';
  modal.style.height = '100vh';
  modal.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
  modal.style.display = 'flex';
  modal.style.alignItems = 'center';
  modal.style.justifyContent = 'center';
  modal.style.zIndex = '10000';
  modal.style.fontFamily = 'Arial, sans-serif';

  // 创建内容容器
  const content = document.createElement('div');
  content.style.backgroundColor = '#1e293b';
  content.style.borderRadius = '12px';
  content.style.padding = '30px';
  content.style.maxWidth = '600px';
  content.style.width = '90%';
  content.style.color = '#ffffff';
  content.style.boxShadow = '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)';

  // 标题
  const title = document.createElement('h2');
  title.textContent = '交互延迟统计报告';
  title.style.margin = '0 0 20px 0';
  title.style.fontSize = '24px';
  title.style.fontWeight = 'bold';
  title.style.color = '#60a5fa';
  title.style.textAlign = 'center';

  // 简化的统计信息
  const statsHtml = `
    <div style="margin-bottom: 30px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div style="background: #374151; padding: 20px; border-radius: 12px; flex: 1; margin-right: 15px;">
          <div style="font-size: 16px; color: #9ca3af; margin-bottom: 8px;">交互次数</div>
          <div style="font-size: 32px; font-weight: bold; color: #60a5fa;">${stats.totalInteractions}</div>
        </div>
        <div style="background: #374151; padding: 20px; border-radius: 12px; flex: 1; margin-left: 15px;">
          <div style="font-size: 16px; color: #9ca3af; margin-bottom: 8px;">平均交互延迟</div>
          <div style="font-size: 32px; font-weight: bold; color: #10b981;">${stats.averageTotalDelay.toFixed(1)}ms</div>
        </div>
      </div>
    </div>
  `;

  content.innerHTML = statsHtml;
  content.insertBefore(title, content.firstChild);

  // 关闭按钮
  const closeButton = document.createElement('button');
  closeButton.textContent = '关闭';
  closeButton.style.width = '100%';
  closeButton.style.padding = '12px';
  closeButton.style.backgroundColor = '#3b82f6';
  closeButton.style.color = '#ffffff';
  closeButton.style.border = 'none';
  closeButton.style.borderRadius = '8px';
  closeButton.style.fontSize = '16px';
  closeButton.style.fontWeight = 'bold';
  closeButton.style.cursor = 'pointer';
  closeButton.style.marginTop = '20px';
  closeButton.style.transition = 'background-color 0.2s';

  closeButton.addEventListener('mouseenter', () => {
    closeButton.style.backgroundColor = '#2563eb';
  });

  closeButton.addEventListener('mouseleave', () => {
    closeButton.style.backgroundColor = '#3b82f6';
  });

  closeButton.addEventListener('click', () => {
    document.body.removeChild(modal);
  });

  content.appendChild(closeButton);
  modal.appendChild(content);
  document.body.appendChild(modal);

  // 输出到控制台
  console.log('\n=== 交互延迟统计报告 ===');
  console.log(`交互次数: ${stats.totalInteractions}`);
  console.log(`平均交互延迟: ${stats.averageTotalDelay.toFixed(1)}ms`);
  console.log('========================\n');
}

// 重置交互延迟历史记录
export function resetInteractionDelayHistory() {
  interactionDelayHistory = [];
  lastInteractionFrame = 0;
  currentInteractionId = 0;
  console.log('[交互延迟] 历史记录已重置');
}

// 获取交互延迟统计信息
export function getInteractionDelayStats() {
  return calculateAverageInteractionDelay();
}

// 获取交互延迟历史记录
export function getInteractionDelayHistory() {
  return interactionDelayHistory.map(record => ({
    interactionId: record.interactionId,
    frameNumber: record.frameNumber,
    cameraPosition: record.cameraPosition,
    viewportChunks: record.viewportChunks,
    stats: record.getStats(),
    timestamp: record.startTime
  }));
}
