// SSL配置文件 - 可选
export const sslConfig = {
  // 自定义证书路径（如果需要）
  // cert: './certs/cert.pem',
  // key: './certs/key.pem',
  
  // 证书选项
  options: {
    // 允许自签名证书
    rejectUnauthorized: false,
    
    // 证书验证选项
    checkServerIdentity: () => undefined
  }
};

// 开发环境HTTPS配置
export const devHttpsConfig = {
  enabled: true,
  port: 3000,
  host: '0.0.0.0',
  
  // 自动生成证书
  autoCert: true,
  
  // 证书缓存目录
  certCacheDir: './.vite/certs',
  
  // 证书有效期（天）
  certValidityDays: 30
};
