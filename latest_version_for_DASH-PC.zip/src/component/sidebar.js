import { globalState } from '../../global'; 

export function createSidebar() {
  const sidebar = document.createElement('div');
  sidebar.classList.add('sidebar');

  sidebar.style.padding = '25px';
  sidebar.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
  sidebar.style.backdropFilter = 'blur(20px)';
  sidebar.style.borderRadius = '0';
  sidebar.style.boxShadow = '4px 0 20px rgba(0, 0, 0, 0.1)';
  sidebar.style.fontFamily = 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  sidebar.style.width = '100%';
  sidebar.style.height = '100%';
  sidebar.style.overflowY = 'hidden'; // 移除滚动条
  sidebar.style.maxHeight = 'calc(90vh - 45px)'; 

  // 自定义滚动条 - 移除
  // sidebar.style.setProperty('--scrollbar-width', '6px');
  // sidebar.style.setProperty('--scrollbar-track', 'rgba(0, 0, 0, 0.05)');
  // sidebar.style.setProperty('--scrollbar-thumb', 'rgba(102, 126, 234, 0.3)');

  const welcomeMessage = document.createElement('h1');
  welcomeMessage.textContent = '📊 实时监控';
  welcomeMessage.style.textAlign = 'center';
  welcomeMessage.style.marginBottom = '30px'; // 从25px增加到30px
  welcomeMessage.style.color = '#1f2937';
  welcomeMessage.style.fontSize = '1.6em'; // 从1.5em增加到1.6em
  welcomeMessage.style.fontWeight = '700';
  welcomeMessage.style.background = 'linear-gradient(135deg, #667eea, #764ba2)';
  welcomeMessage.style.webkitBackgroundClip = 'text';
  welcomeMessage.style.webkitTextFillColor = 'transparent';
  welcomeMessage.style.backgroundClip = 'text';
  sidebar.appendChild(welcomeMessage);

  const cardContainer = document.createElement('div');
  cardContainer.style.display = 'grid';
  cardContainer.style.gridTemplateColumns = '1fr';
  cardContainer.style.gap = '20px';

  // 移除ABR算法信息卡片，改为缓冲区占用率卡片
  // const abrAlgorithmCard = createCard('🎯 ABR算法', 'ABRAlgorithm', 'Buffer-based', '', '🎯');
  // cardContainer.appendChild(abrAlgorithmCard);

  function createCard(title, id, initialValue, additionalContent = '', icon = '📈') {
    const card = document.createElement('div');
    card.classList.add('card');
    if (id === 'SelectedQualityLevel') {
      card.style.minHeight = '70px'; // 调小质量等级卡片高度
      card.style.padding = '10px 0';
    }
    card.style.background = 'white';
    card.style.borderRadius = '16px';
    card.style.boxShadow = '0 2px 12px rgba(102, 126, 234, 0.08)';
    card.style.padding = '18px 0';
    card.style.display = 'flex';
    card.style.flexDirection = 'column';
    card.style.alignItems = 'center';
    card.style.justifyContent = 'center';
    card.style.transition = 'box-shadow 0.2s';
    card.style.position = 'relative';
    card.style.marginBottom = '0px';
    card.style.marginTop = '0px';
    card.style.border = '1px solid #e5e7eb';
    card.style.minWidth = '0';
    card.style.maxWidth = '100%';
    card.style.overflow = 'hidden';

    // 添加悬停效果
    card.addEventListener('mouseenter', () => {
      card.style.transform = 'translateY(-5px)';
      card.style.boxShadow = '0 8px 30px rgba(0, 0, 0, 0.12)';
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = 'translateY(0)';
      card.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.08)';
    });

    // 添加渐变背景
    const gradientBg = document.createElement('div');
    gradientBg.style.position = 'absolute';
    gradientBg.style.top = '0';
    gradientBg.style.left = '0';
    gradientBg.style.right = '0';
    gradientBg.style.height = '4px';
    gradientBg.style.background = 'linear-gradient(135deg, #667eea, #764ba2)';
    gradientBg.style.borderRadius = '16px 16px 0 0';
    card.appendChild(gradientBg);

    const headerContainer = document.createElement('div');
    headerContainer.style.display = 'flex';
    headerContainer.style.alignItems = 'center';
    headerContainer.style.gap = '10px';
    headerContainer.style.marginBottom = '18px'; // 从15px增加到18px

    const iconElement = document.createElement('span');
    iconElement.textContent = icon;
    iconElement.style.fontSize = '22px'; // 从20px增加到22px

    const cardTitle = document.createElement('h3');
    cardTitle.textContent = title;
    cardTitle.style.margin = '0';
    cardTitle.style.color = '#374151';
    cardTitle.style.fontSize = '1.15em'; // 从1.1em增加到1.15em
    cardTitle.style.fontWeight = '600';

    headerContainer.appendChild(iconElement);
    headerContainer.appendChild(cardTitle);

    const cardValue = document.createElement('div');
    cardValue.id = id;
    cardValue.innerHTML = initialValue;
    cardValue.style.fontSize = '2em'; // 从1.8em增加到2em
    cardValue.style.color = '#1f2937';
    cardValue.style.fontWeight = '700';
    cardValue.style.marginBottom = '12px'; // 从10px增加到12px
    cardValue.style.textAlign = 'center';

    card.appendChild(headerContainer);
    card.appendChild(cardValue);

    if (additionalContent) {
      const additionalInfo = document.createElement('div');
      additionalInfo.innerHTML = additionalContent;
      additionalInfo.style.fontSize = '0.9em';
      additionalInfo.style.color = '#6b7280';
      additionalInfo.style.textAlign = 'center';
      additionalInfo.style.padding = '12px'; // 从10px增加到12px
      additionalInfo.style.backgroundColor = 'rgba(102, 126, 234, 0.05)';
      additionalInfo.style.borderRadius = '10px'; // 从8px增加到10px
      additionalInfo.style.border = '1px solid rgba(102, 126, 234, 0.1)';
      card.appendChild(additionalInfo);
    }

    return card;
  }

  // 创建算法结果卡片 - 移除
  // const algorithm1Card = createCard(
  //   '算法结果',
  //   'algorithm1',
  //   '<div style="text-align: center; color: #6b7280; font-size: 14px;">算法运行中...</div>',
  //   '',
  //   '🧠'
  // );

  // 调整卡片间距，使其更美观
  cardContainer.style.gap = '15px'; // 增加卡片间距

  cardContainer.appendChild(
    createCard('🌐 带宽', 'bandwidth', '0 MBps', '', '📡')
  );
  cardContainer.appendChild(
    createCard('📈 带宽增长', 'bandwidthIncrease', 
    '<span id="bandwidthIncreaseDisplay" style="color: #10b981;">0%</span>', '', '📊')
  );
  cardContainer.appendChild(
    createCard('🎬 质量等级', 'SelectedQualityLevel', 
    '0', 'FPS: <span id="fps" style="color: #667eea; font-weight: 600;">0</span>', '⚡')
  );
  // 新增缓冲区使用率卡片
  cardContainer.appendChild(
    createCard('🗃️ 缓冲区使用率', 'bufferUsageRate', '<span id="bufferUsageRateDisplay" style="color: #667eea;">0%</span>', '', '🗃️')
  );
  // cardContainer.appendChild(algorithm1Card); // 移除算法结果卡片

  sidebar.appendChild(cardContainer);

  // 添加实时更新
  setInterval(updateSideBar, 50);

  function updateSideBar() {
    // 更新带宽显示
    const bandwidthElement = document.getElementById('bandwidth');
    if (bandwidthElement && globalState.bandwidth !== undefined) {
      bandwidthElement.textContent = globalState.bandwidth.toFixed(2) + ' MBps';
    }

    // 更新带宽增长显示
    const bandwidthIncreaseElement = document.getElementById('bandwidthIncreaseDisplay');
    if (bandwidthIncreaseElement && globalState.bandwidthIncrease !== undefined) {
      const increase = globalState.bandwidthIncrease;
      bandwidthIncreaseElement.textContent = increase.toFixed(2) + '%';
      
      // 根据增长值改变颜色
      if (increase > 0) {
        bandwidthIncreaseElement.style.color = '#10b981'; // 绿色
      } else if (increase < 0) {
        bandwidthIncreaseElement.style.color = '#ef4444'; // 红色
      } else {
        bandwidthIncreaseElement.style.color = '#6b7280'; // 灰色
      }
    }

    // 更新质量等级显示
    const qualityElement = document.getElementById('SelectedQualityLevel');
    if (qualityElement && globalState.currentQualityLevel !== undefined) {
      const qualityLevel = globalState.currentQualityLevel;
      qualityElement.textContent = qualityLevel;
      
      // 根据质量等级改变颜色
      if (qualityLevel == 1) {
        qualityElement.style.color = '#10b981'; // 绿色
      } else if (qualityLevel == 2) {
        qualityElement.style.color = '#f59e0b'; // 黄色
      } else if (qualityLevel == 3) {
        qualityElement.style.color = '#ef4444'; // 红色
      } else {
        qualityElement.style.color = '#6b7280'; // 默认灰色
      }
    }

    // 更新FPS显示
    const fpsElement = document.getElementById('fps');
    if (fpsElement && globalState.fps !== undefined) {
      fpsElement.textContent = globalState.fps.toFixed(1);
    }

    // 更新缓冲区使用率显示
    const bufferUsageRateElement = document.getElementById('bufferUsageRateDisplay');
    if (bufferUsageRateElement && globalState.bufferUsageRate !== undefined) {
      bufferUsageRateElement.textContent = globalState.bufferUsageRate.toFixed(1) + '%';
    }

    // 移除ABR算法显示更新代码
    // const abrAlgorithmElement = document.getElementById('ABRAlgorithm');
    // if (abrAlgorithmElement && globalState.currentABRAlgorithm !== undefined) {
    //   const algorithm = globalState.currentABRAlgorithm;
    //   let displayText = '';
    //   let color = '#6b7280';
    //   
    //   switch (algorithm) {
    //     case 'buffer-based':
    //       displayText = 'Buffer-based';
    //       color = '#10b981'; // 绿色
    //       break;
    //     case 'rb-rmpc':
    //       displayText = 'RB.RMPC';
    //       color = '#f59e0b'; // 黄色
    //       break;
    //     case 'rl':
    //       displayText = 'RL';
    //       color = '#667eea'; // 蓝色
    //       break;
    //     default:
    //       displayText = 'Buffer-based';
    //       color = '#10b981';
    //   }
    //   
    //   abrAlgorithmElement.textContent = displayText;
    //   abrAlgorithmElement.style.color = color;
    // }
  }

  return sidebar;
}


