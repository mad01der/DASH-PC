import { ConstantColorFactor } from 'three';
import { init3DView } from '../../main.js';
import { globalState } from '../../global.js';

export function createContent() {
  const content = document.createElement('div');
  content.classList.add('content');
  content.style.display = 'flex';
  content.style.flexDirection = 'column';
  content.style.alignItems = 'center';
  content.style.justifyContent = 'flex-start';
  content.style.padding = '15px'; // 从20px减少到15px
  content.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
  content.style.backdropFilter = 'blur(20px)';
  content.style.minHeight = '100%';
  content.style.overflow = 'visible';

  const container = document.createElement('div');
  container.classList.add('container');
  container.style.width = '100%';
  container.style.maxWidth = '1135px'; // 从1400px增加到1600px，与3D容器保持一致
  container.style.display = 'flex';
  container.style.flexDirection = 'column';
  container.style.alignItems = 'center';
  container.style.minHeight = '100%';
  container.style.height = '100%'; // 确保容器占满高度

  const headerSection = document.createElement('div');
  headerSection.style.textAlign = 'center';
  headerSection.style.marginBottom = '15px'; // 从20px减少到15px
  headerSection.style.width = '100%';
  headerSection.style.flexShrink = '0'; // 防止headerSection被压缩

  const title = document.createElement('h1');
  title.textContent = '🎯 3D 点云可视化';
  title.style.fontSize = '1.8em'; // 从2.2em减少到1.8em
  title.style.fontWeight = '700';
  title.style.marginBottom = '6px'; // 从8px减少到6px
  title.style.background = 'linear-gradient(135deg, #667eea, #764ba2)';
  title.style.webkitBackgroundClip = 'text';
  title.style.webkitTextFillColor = 'transparent';
  title.style.backgroundClip = 'text';

  const description = document.createElement('p');
  description.textContent = '在下方可视化区域中探索3D点云数据，体验沉浸式的点云观看体验';
  description.style.fontSize = '1em'; // 从1.1em减少到1em
  description.style.color = '#6b7280';
  description.style.marginBottom = '12px'; // 从15px减少到12px
  description.style.maxWidth = '600px';
  description.style.margin = '0 auto 12px'; // 从15px减少到12px

  const statsContainer = document.createElement('div');
  statsContainer.style.display = 'flex';
  statsContainer.style.gap = '20px';
  statsContainer.style.marginBottom = '15px'; // 从20px减少到15px
  statsContainer.style.flexWrap = 'wrap';
  statsContainer.style.justifyContent = 'center';

  const createStatItem = (icon, label, value, color = '#667eea') => {
    const statItem = document.createElement('div');
    statItem.style.display = 'flex';
    statItem.style.alignItems = 'center';
    statItem.style.gap = '8px';
    statItem.style.padding = '8px 16px';
    statItem.style.backgroundColor = 'rgba(255, 255, 255, 0.8)';
    statItem.style.borderRadius = '20px';
    statItem.style.border = `1px solid ${color}20`;
    statItem.style.fontSize = '14px';
    statItem.style.fontWeight = '500';

    const iconSpan = document.createElement('span');
    iconSpan.textContent = icon;
    iconSpan.style.fontSize = '16px';

    const labelSpan = document.createElement('span');
    labelSpan.textContent = label;
    labelSpan.style.color = '#6b7280';

    const valueSpan = document.createElement('span');
    valueSpan.textContent = value;
    valueSpan.style.color = color;
    valueSpan.style.fontWeight = '600';

    statItem.appendChild(iconSpan);
    statItem.appendChild(labelSpan);
    statItem.appendChild(valueSpan);

    return statItem;
  };

  statsContainer.appendChild(createStatItem('📊', '点云数量:', '1.2M', '#667eea'));
  statsContainer.appendChild(createStatItem('📊', '帧率:', '~10 FPS', '#10b981'));
  statsContainer.appendChild(createStatItem('🌐', '质量:', '自适应', '#f59e0b'));

  headerSection.appendChild(title);
  headerSection.appendChild(description);
  headerSection.appendChild(statsContainer);

  const threeContainer = document.createElement('div');
  threeContainer.id = 'three-container';
  threeContainer.style.width = '100%';
  threeContainer.style.height = '80%'; // 从100%减少到85%，使高度稍微小一些
  threeContainer.style.minHeight = '450px'; // 从500px减少到450px
  threeContainer.style.marginBottom = '20px';
  threeContainer.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
  threeContainer.style.borderRadius = '20px';
  threeContainer.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.1)';
  threeContainer.style.position = 'relative';
  threeContainer.style.overflow = 'hidden';
  threeContainer.style.border = '1px solid rgba(255, 255, 255, 0.2)';
  threeContainer.style.backdropFilter = 'blur(10px)';
  threeContainer.style.flex = '1'; // 添加flex属性使其填充可用空间
  threeContainer.style.maxWidth = '1600px'; // 增加最大宽度，从1400px增加到1600px

  // 添加渐变边框效果
  const gradientBorder = document.createElement('div');
  gradientBorder.style.position = 'absolute';
  gradientBorder.style.top = '0';
  gradientBorder.style.left = '0';
  gradientBorder.style.right = '0';
  gradientBorder.style.bottom = '0';
  gradientBorder.style.borderRadius = '20px';
  gradientBorder.style.padding = '2px';
  gradientBorder.style.background = 'linear-gradient(135deg, #667eea, #764ba2, #f093fb)';
  gradientBorder.style.zIndex = '-1';

  const innerContainer = document.createElement('div');
  innerContainer.style.width = '100%';
  innerContainer.style.height = '100%';
  innerContainer.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
  innerContainer.style.borderRadius = '18px';
  innerContainer.style.position = 'relative';

  gradientBorder.appendChild(innerContainer);
  threeContainer.appendChild(gradientBorder);

  // 窗口大小调整事件
  window.addEventListener('resize', () => {
    if (threeContainer && threeContainer.clientWidth && threeContainer.clientHeight) {
      init3DView(threeContainer);
    }
  });

  // 加载覆盖层
  const loadingOverlay = document.createElement('div');
  loadingOverlay.style.position = 'absolute';
  loadingOverlay.style.top = '0';
  loadingOverlay.style.left = '0';
  loadingOverlay.style.width = '100%';
  loadingOverlay.style.height = '100%';
  loadingOverlay.style.display = 'none';
  loadingOverlay.style.justifyContent = 'center';
  loadingOverlay.style.alignItems = 'center';
  loadingOverlay.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
  loadingOverlay.style.backdropFilter = 'blur(10px)';
  loadingOverlay.style.zIndex = '10';
  loadingOverlay.style.flexDirection = 'column';
  loadingOverlay.style.borderRadius = '20px';

  // 创建加载动画容器
  const loadingContent = document.createElement('div');
  loadingContent.style.textAlign = 'center';
  loadingContent.style.padding = '40px';

  // 创建脉冲动画的圆圈
  const pulseCircle = document.createElement('div');
  pulseCircle.style.width = '60px';
  pulseCircle.style.height = '60px';
  pulseCircle.style.borderRadius = '50%';
  pulseCircle.style.background = 'linear-gradient(135deg, #667eea, #764ba2)';
  pulseCircle.style.margin = '0 auto 20px';
  pulseCircle.style.animation = 'pulse 2s ease-in-out infinite';
  pulseCircle.style.position = 'relative';

  // 添加内部旋转圆圈
  const innerCircle = document.createElement('div');
  innerCircle.style.position = 'absolute';
  innerCircle.style.top = '50%';
  innerCircle.style.left = '50%';
  innerCircle.style.transform = 'translate(-50%, -50%)';
  innerCircle.style.width = '40px';
  innerCircle.style.height = '40px';
  innerCircle.style.border = '3px solid rgba(255, 255, 255, 0.3)';
  innerCircle.style.borderTop = '3px solid white';
  innerCircle.style.borderRadius = '50%';
  innerCircle.style.animation = 'spin 1s linear infinite';

  pulseCircle.appendChild(innerCircle);

  const loadingText = document.createElement('div');
  loadingText.textContent = '正在加载点云数据...';
  loadingText.style.marginTop = '15px';
  loadingText.style.color = '#374151';
  loadingText.style.fontSize = '16px';
  loadingText.style.fontWeight = '500';

  const loadingSubtext = document.createElement('div');
  loadingSubtext.textContent = '请稍候，正在初始化3D渲染引擎';
  loadingSubtext.style.marginTop = '8px';
  loadingSubtext.style.color = '#6b7280';
  loadingSubtext.style.fontSize = '14px';

  loadingContent.appendChild(pulseCircle);
  loadingContent.appendChild(loadingText);
  loadingContent.appendChild(loadingSubtext);
  loadingOverlay.appendChild(loadingContent);

  // 添加动画样式
  const style = document.createElement('style');
  style.textContent = `
    @keyframes pulse {
      0%, 100% {
        transform: scale(1);
        opacity: 1;
      }
      50% {
        transform: scale(1.1);
        opacity: 0.8;
      }
    }
    
    @keyframes spin {
      0% { transform: translate(-50%, -50%) rotate(0deg); }
      100% { transform: translate(-50%, -50%) rotate(360deg); }
    }
    
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  `;
  document.head.appendChild(style);

  threeContainer.appendChild(loadingOverlay);

  // 控制面板 - 移除所有按钮
  const controlPanel = document.createElement('div');
  controlPanel.style.display = 'none'; // 隐藏控制面板

  function updateLoadingState() {
    const isLoading = globalState.is_loading;
    loadingOverlay.style.display = isLoading === 0 ? 'flex' : 'none';
  }

  container.appendChild(headerSection);
  container.appendChild(threeContainer);
  container.appendChild(controlPanel);
  content.appendChild(container);

  // 初始化3D视图
  init3DView(threeContainer);
  
  // 实时更新加载状态
  setInterval(updateLoadingState, 10);

  // 添加页面加载动画
  setTimeout(() => {
    content.style.animation = 'fadeInUp 0.8s ease-out';
  }, 100);

  return content;
}


