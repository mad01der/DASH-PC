export function Header() {
    const header = document.createElement('header');
    header.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
    header.style.color = '#fff';
    header.style.display = 'flex';
    header.style.justifyContent = 'space-between';
    header.style.alignItems = 'center';
    header.style.padding = '15px 25px';
    header.style.boxSizing = 'border-box';
    header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.1)';
    header.style.backdropFilter = 'blur(20px)';
    header.style.borderBottom = '1px solid rgba(255, 255, 255, 0.1)';

    const logo = document.createElement('div');
    logo.textContent = '🎯 DASH Point Cloud';
    logo.style.fontSize = '24px';
    logo.style.fontWeight = '600';
    logo.style.display = 'flex';
    logo.style.alignItems = 'center';
    logo.style.gap = '10px';

    const githubLink = document.createElement('a');
    githubLink.href = 'https://github.com/mad01der/DASH-PC';
    githubLink.target = '_blank';
    githubLink.style.textDecoration = 'none';
    githubLink.style.color = 'white';
    githubLink.style.transition = 'transform 0.3s ease';
    
    const githubIcon = document.createElement('img');
    githubIcon.src = './github.png';
    githubIcon.alt = 'GitHub';
    githubIcon.style.width = '32px';
    githubIcon.style.height = '32px';
    githubIcon.style.borderRadius = '50%';
    githubIcon.style.transition = 'transform 0.3s ease';
    
    githubLink.appendChild(githubIcon);
    githubLink.addEventListener('mouseenter', () => {
        githubIcon.style.transform = 'scale(1.1) rotate(5deg)';
    });
    githubLink.addEventListener('mouseleave', () => {
        githubIcon.style.transform = 'scale(1) rotate(0deg)';
    });

    header.appendChild(logo);
    header.appendChild(githubLink);

    const controlsBar = document.createElement('div');
    controlsBar.style.display = 'flex';
    controlsBar.style.alignItems = 'center';
    controlsBar.style.justifyContent = 'flex-start';
    controlsBar.style.gap = '15px';
    controlsBar.style.height = '80px';
    controlsBar.style.padding = '15px 25px';
    controlsBar.style.boxSizing = 'border-box';
    controlsBar.style.background = 'rgba(255, 255, 255, 0.95)';
    controlsBar.style.backdropFilter = 'blur(20px)';
    controlsBar.style.borderBottom = '1px solid rgba(0, 0, 0, 0.1)';
    controlsBar.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.05)';

    const createButton = (text, bgColor, gradient, shadow) => {
        const button = document.createElement('button');
        button.textContent = text;
        button.style.padding = '10px 20px';
        button.style.backgroundColor = bgColor;
        button.style.backgroundImage = gradient;
        button.style.border = 'none';
        button.style.borderRadius = '8px';
        button.style.color = '#fff';
        button.style.cursor = 'pointer';
        button.style.boxShadow = shadow;
        button.style.transition = 'all 0.3s ease';
        button.style.fontWeight = '500';
        button.style.fontSize = '14px';

        button.addEventListener('mouseenter', () => {
            button.style.transform = 'translateY(-2px) scale(1.02)';
            button.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.2)';
        });
        button.addEventListener('mouseleave', () => {
            button.style.transform = 'translateY(0) scale(1)';
            button.style.boxShadow = shadow;
        });

        return button;
    };

    const streamButton = createButton(
        'Stream',
        '#667eea',
        'linear-gradient(135deg, #667eea, #764ba2)',
        '0 4px 15px rgba(102, 126, 234, 0.3)'
    );

    // 移除输入框相关代码
    // const input = document.createElement('input');
    // input.type = 'text';
    // input.placeholder = 'On-demand...';
    // input.id = 'mpd-input';
    // input.style.flex = '1';
    // input.style.padding = '12px 16px';
    // input.style.border = '2px solid #e2e8f0';
    // input.style.borderRadius = '8px';
    // input.style.fontSize = '14px';
    // input.style.transition = 'all 0.3s ease';
    // input.style.background = 'white';
    // input.style.minWidth = '300px';

    // input.addEventListener('focus', () => {
    //     input.style.borderColor = '#667eea';
    //     input.style.boxShadow = '0 0 0 3px rgba(102, 126, 234, 0.1)';
    // });

    // input.addEventListener('blur', () => {
    //     input.style.borderColor = '#e2e8f0';
    //     input.style.boxShadow = 'none';
    // });

    const stopButton = document.createElement('button');
    stopButton.textContent = '🔄 Refresh';
    stopButton.style.padding = '10px 20px';
    stopButton.style.backgroundColor = '#f8fafc';
    stopButton.style.border = '2px solid #e2e8f0';
    stopButton.style.cursor = 'pointer';
    stopButton.style.borderRadius = '8px';
    stopButton.style.color = '#374151';
    stopButton.style.transition = 'all 0.3s ease';
    stopButton.style.fontWeight = '500';
    stopButton.style.fontSize = '14px';

    stopButton.addEventListener('mouseenter', () => {
        stopButton.style.backgroundColor = '#f1f5f9';
        stopButton.style.transform = 'translateY(-1px)';
    });

    stopButton.addEventListener('mouseleave', () => {
        stopButton.style.backgroundColor = '#f8fafc';
        stopButton.style.transform = 'translateY(0)';
    });

    stopButton.addEventListener('click', () => {
        location.reload();
    });

    const loadButton = createButton(
        '🚀 Load',
        '#667eea',
        'linear-gradient(135deg, #667eea, #764ba2)',
        '0 4px 15px rgba(102, 126, 234, 0.3)'
    );
    loadButton.id = "startButton";
    loadButton.addEventListener('click', () => {
        const mpdUrl = 'https://localhost/drc_scable/pointcloud.mpd';    // 替换为实际的MPD文件路径
        // 直接触发事件，不再需要设置输入框的值
        const event = new CustomEvent('inputValueSelected', {
            detail: { value: mpdUrl }
        });
        window.dispatchEvent(event);
    });

    // 添加ABR算法选择框
    const abrSelectContainer = document.createElement('div');
    abrSelectContainer.style.display = 'flex';
    abrSelectContainer.style.alignItems = 'center';
    abrSelectContainer.style.gap = '8px';
    abrSelectContainer.style.marginLeft = '15px';

    const abrLabel = document.createElement('label');
    abrLabel.textContent = 'ABR算法:';
    abrLabel.style.fontSize = '14px';
    abrLabel.style.fontWeight = '500';
    abrLabel.style.color = '#374151';
    abrLabel.style.whiteSpace = 'nowrap';

    const abrSelect = document.createElement('select');
    abrSelect.id = 'abr-algorithm-select';
    abrSelect.style.padding = '8px 12px';
    abrSelect.style.border = '2px solid #e2e8f0';
    abrSelect.style.borderRadius = '8px';
    abrSelect.style.fontSize = '14px';
    abrSelect.style.backgroundColor = 'white';
    abrSelect.style.color = '#374151';
    abrSelect.style.cursor = 'pointer';
    abrSelect.style.transition = 'all 0.3s ease';
    abrSelect.style.minWidth = '140px';
    abrSelect.style.outline = 'none';

    // 添加选项
    const options = [
        { value: 'buffer-based', text: 'Buffer-based' },
        { value: 'rb', text: 'RB' },
        { value: 'rmpc', text: 'RMPC' },
        { value: 'rl', text: 'RL' }
    ];

    options.forEach(option => {
        const optionElement = document.createElement('option');
        optionElement.value = option.value;
        optionElement.textContent = option.text;
        abrSelect.appendChild(optionElement);
    });

    // 设置默认值为Buffer-based
    abrSelect.value = 'buffer-based';

    // 添加焦点和悬停效果
    abrSelect.addEventListener('focus', () => {
        abrSelect.style.borderColor = '#667eea';
        abrSelect.style.boxShadow = '0 0 0 3px rgba(102, 126, 234, 0.1)';
    });

    abrSelect.addEventListener('blur', () => {
        abrSelect.style.borderColor = '#e2e8f0';
        abrSelect.style.boxShadow = 'none';
    });

    abrSelect.addEventListener('change', () => {
        const selectedAlgorithm = abrSelect.value;
        console.log(`[ABR选择] 用户选择了算法: ${selectedAlgorithm}`);
        
        // 触发ABR算法选择事件
        const event = new CustomEvent('abrAlgorithmChanged', {
            detail: { algorithm: selectedAlgorithm }
        });
        window.dispatchEvent(event);
    });

    abrSelectContainer.appendChild(abrLabel);
    abrSelectContainer.appendChild(abrSelect);

    // 添加视口预测算法选择框
    const viewportSelectContainer = document.createElement('div');
    viewportSelectContainer.style.display = 'flex';
    viewportSelectContainer.style.alignItems = 'center';
    viewportSelectContainer.style.gap = '8px';
    viewportSelectContainer.style.marginLeft = '15px';

    const viewportLabel = document.createElement('label');
    viewportLabel.textContent = '视口预测:';
    viewportLabel.style.fontSize = '14px';
    viewportLabel.style.fontWeight = '500';
    viewportLabel.style.color = '#374151';
    viewportLabel.style.whiteSpace = 'nowrap';

    const viewportSelect = document.createElement('select');
    viewportSelect.id = 'viewport-prediction-select';
    viewportSelect.style.padding = '8px 12px';
    viewportSelect.style.border = '2px solid #e2e8f0';
    viewportSelect.style.borderRadius = '8px';
    viewportSelect.style.fontSize = '14px';
    viewportSelect.style.backgroundColor = 'white';
    viewportSelect.style.color = '#374151';
    viewportSelect.style.cursor = 'pointer';
    viewportSelect.style.transition = 'all 0.3s ease';
    viewportSelect.style.minWidth = '140px';
    viewportSelect.style.outline = 'none';

    // 添加视口预测算法选项
    const viewportOptions = [
        { value: 'lr', text: 'LR (Linear Regression)' },
        { value: 'lstm', text: 'LSTM' }
    ];

    viewportOptions.forEach(option => {
        const optionElement = document.createElement('option');
        optionElement.value = option.value;
        optionElement.textContent = option.text;
        viewportSelect.appendChild(optionElement);
    });

    // 设置默认值为LR
    viewportSelect.value = 'lr';

    // 添加焦点和悬停效果
    viewportSelect.addEventListener('focus', () => {
        viewportSelect.style.borderColor = '#667eea';
        viewportSelect.style.boxShadow = '0 0 0 3px rgba(102, 126, 234, 0.1)';
    });

    viewportSelect.addEventListener('blur', () => {
        viewportSelect.style.borderColor = '#e2e8f0';
        viewportSelect.style.boxShadow = 'none';
    });

    viewportSelect.addEventListener('change', () => {
        const selectedAlgorithm = viewportSelect.value;
        console.log(`[视口预测选择] 用户选择了算法: ${selectedAlgorithm}`);
        
        // 触发视口预测算法选择事件
        const event = new CustomEvent('viewportPredictionChanged', {
            detail: { algorithm: selectedAlgorithm }
        });
        window.dispatchEvent(event);
    });

    viewportSelectContainer.appendChild(viewportLabel);
    viewportSelectContainer.appendChild(viewportSelect);

    // 添加WebXR功能按钮
    const webxrButtonContainer = document.createElement('div');
    webxrButtonContainer.style.display = 'flex';
    webxrButtonContainer.style.alignItems = 'center';
    webxrButtonContainer.style.gap = '8px';
    webxrButtonContainer.style.marginLeft = '15px';

    const webxrButton = createButton(
        '🥽 WebXR',
        '#f093fb',
        'linear-gradient(135deg, #f093fb, #667eea)',
        '0 4px 15px rgba(240, 147, 251, 0.3)'
    );
    webxrButton.id = 'webxr-button';
    webxrButton.style.position = 'relative';
    
    // 添加WebXR状态指示器
    const webxrStatus = document.createElement('div');
    webxrStatus.id = 'webxr-status';
    webxrStatus.style.position = 'absolute';
    webxrStatus.style.top = '-8px';
    webxrStatus.style.right = '-8px';
    webxrStatus.style.width = '16px';
    webxrStatus.style.height = '16px';
    webxrStatus.style.borderRadius = '50%';
    webxrStatus.style.backgroundColor = '#6b7280';
    webxrStatus.style.border = '2px solid white';
    webxrStatus.style.fontSize = '10px';
    webxrStatus.style.display = 'flex';
    webxrStatus.style.alignItems = 'center';
    webxrStatus.style.justifyContent = 'center';
    webxrStatus.style.color = 'white';
    webxrStatus.style.fontWeight = 'bold';
    webxrStatus.textContent = '?';
    webxrStatus.title = 'WebXR状态: 未知';
    
    webxrButton.appendChild(webxrStatus);
    
    // 检查WebXR支持状态
    const checkWebXRSupport = () => {
        if (navigator.xr) {
            navigator.xr.isSessionSupported('immersive-vr').then((supported) => {
                if (supported) {
                    webxrStatus.style.backgroundColor = '#10b981';
                    webxrStatus.textContent = '✓';
                    webxrStatus.title = 'WebXR状态: 支持VR';
                    webxrButton.disabled = false;
                } else {
                    webxrStatus.style.backgroundColor = '#f59e0b';
                    webxrStatus.textContent = '⚠';
                    webxrStatus.title = 'WebXR状态: 不支持VR';
                    webxrButton.disabled = true;
                }
            }).catch(() => {
                webxrStatus.style.backgroundColor = '#ef4444';
                webxrStatus.textContent = '✗';
                webxrStatus.title = 'WebXR状态: 不支持';
                webxrButton.disabled = true;
            });
        } else {
            webxrStatus.style.backgroundColor = '#ef4444';
            webxrStatus.textContent = '✗';
            webxrStatus.title = 'WebXR状态: 浏览器不支持';
            webxrButton.disabled = true;
        }
    };
    
    // 页面加载时检查WebXR支持
    checkWebXRSupport();
    
    // 添加WebXR按钮点击事件
    webxrButton.addEventListener('click', () => {
        if (webxrButton.disabled) {
            alert('您的设备或浏览器不支持WebXR功能');
            return;
        }
        
        // 触发WebXR启动事件
        const event = new CustomEvent('webxrRequested', {
            detail: { action: 'start' }
        });
        window.dispatchEvent(event);
        
        // 更新按钮状态
        webxrButton.textContent = '🥽 VR中...';
        webxrButton.style.background = 'linear-gradient(135deg, #10b981, #059669)';
    });
    
    webxrButtonContainer.appendChild(webxrButton);

    // 移除Select MPD按钮（showOptionsButton）
    // controlsBar.appendChild(showOptionsButton); // 删除此行
    // controlsBar.appendChild(input); // 移除输入框
    controlsBar.appendChild(stopButton);
    controlsBar.appendChild(loadButton);
    controlsBar.appendChild(abrSelectContainer);
    controlsBar.appendChild(viewportSelectContainer);
    controlsBar.appendChild(webxrButtonContainer);

    const container = document.createElement('div');
    container.appendChild(header);
    container.appendChild(controlsBar);
    return container;
}
