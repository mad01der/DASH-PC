// ABR算法管理器
// 实现四种ABR算法：Buffer-based、RB、RMPC、RL

export class ABRManager {
    constructor() {
        this.currentAlgorithm = 'buffer-based';
        this.algorithmHistory = [];
        this.bufferThresholds = {
            high: 80,    // 高缓冲区阈值
            medium: 60,  // 中等缓冲区阈值
            low: 30      // 低缓冲区阈值
        };
        
        // RL算法相关参数
        this.rlState = {
            learningRate: 0.1,
            explorationRate: 0.1,
            qualityRewards: { 1: 1.0, 2: 0.7, 3: 0.4 },
            bufferRewards: { high: 1.0, medium: 0.5, low: 0.1 }
        };
    }

    // 设置当前ABR算法
    setAlgorithm(algorithm) {
        const oldAlgorithm = this.currentAlgorithm;
        this.currentAlgorithm = algorithm;
        
        // 记录算法切换历史
        this.algorithmHistory.push({
            timestamp: Date.now(),
            from: oldAlgorithm,
            to: algorithm
        });
        
        console.log(`[ABR管理器] 算法从 ${oldAlgorithm} 切换到 ${algorithm}`);
        
        // 重置算法状态
        this.resetAlgorithmState();
        
        return this.currentAlgorithm;
    }

    // 获取当前算法
    getCurrentAlgorithm() {
        return this.currentAlgorithm;
    }

    // 重置算法状态
    resetAlgorithmState() {
        switch (this.currentAlgorithm) {
            case 'rl':
                this.resetRLState();
                break;
            case 'rb':
                this.resetRBState();
                break;
            case 'rmpc':
                this.resetRMPCState();
                break;
            case 'buffer-based':
            default:
                // Buffer-based算法不需要特殊重置
                break;
        }
    }

    // 执行ABR决策
    makeABRDecision(context) {
        const {
            bufferUsageRate,
            bandwidth,
            currentQualityLevel,
            chunkIndex,
            previousBandwidth
        } = context;

        let newQualityLevel = currentQualityLevel;
        let reason = '';

        switch (this.currentAlgorithm) {
            case 'buffer-based':
                ({ newQualityLevel, reason } = this.bufferBasedDecision(bufferUsageRate, currentQualityLevel));
                break;
            case 'rb':
                ({ newQualityLevel, reason } = this.rbDecision(bufferUsageRate, bandwidth, currentQualityLevel, previousBandwidth));
                break;
            case 'rmpc':
                ({ newQualityLevel, reason } = this.rmpcDecision(bufferUsageRate, bandwidth, currentQualityLevel, previousBandwidth));
                break;
            case 'rl':
                ({ newQualityLevel, reason } = this.rlDecision(bufferUsageRate, bandwidth, currentQualityLevel, chunkIndex));
                break;
            default:
                ({ newQualityLevel, reason } = this.bufferBasedDecision(bufferUsageRate, currentQualityLevel));
                break;
        }

        return {
            newQualityLevel,
            reason,
            algorithm: this.currentAlgorithm,
            timestamp: Date.now()
        };
    }

    // Buffer-based ABR算法
    bufferBasedDecision(bufferUsageRate, currentQualityLevel) {
        let newQualityLevel = currentQualityLevel;
        let reason = '';

        if (bufferUsageRate >= this.bufferThresholds.high) {
            // 缓冲区充足，可以提升质量
            if (currentQualityLevel > 1) {
                newQualityLevel = 1;
                reason = `Buffer-based: 缓冲区充足(${bufferUsageRate.toFixed(1)}%)，提升到最高质量(base+delta2)`;
            } else if (currentQualityLevel > 2) {
                newQualityLevel = 2;
                reason = `Buffer-based: 缓冲区充足(${bufferUsageRate.toFixed(1)}%)，提升到中等质量(base+delta1)`;
            }
        } else if (bufferUsageRate >= this.bufferThresholds.medium) {
            // 缓冲区良好，可以轻微提升质量
            if (currentQualityLevel === 3) {
                newQualityLevel = 2;
                reason = `Buffer-based: 缓冲区良好(${bufferUsageRate.toFixed(1)}%)，提升到中等质量(base+delta1)`;
            }
        } else if (bufferUsageRate <= this.bufferThresholds.low) {
            // 缓冲区不足，降低质量
            if (currentQualityLevel === 1) {
                newQualityLevel = 2;
                reason = `Buffer-based: 缓冲区不足(${bufferUsageRate.toFixed(1)}%)，降低到中等质量(base+delta1)`;
            } else if (currentQualityLevel === 2) {
                newQualityLevel = 3;
                reason = `Buffer-based: 缓冲区不足(${bufferUsageRate.toFixed(1)}%)，降低到基础质量(base-line)`;
            }
        } else if (bufferUsageRate <= 20) {
            // 缓冲区严重不足，强制使用最低质量
            newQualityLevel = 3;
            reason = `Buffer-based: 缓冲区严重不足(${bufferUsageRate.toFixed(1)}%)，强制使用基础质量(base-line)`;
        }

        return { newQualityLevel, reason };
    }

    // RB (Rate-Based) ABR算法
    rbDecision(bufferUsageRate, bandwidth, currentQualityLevel, previousBandwidth) {
        let newQualityLevel = currentQualityLevel;
        let reason = '';

        // 计算带宽变化率
        const bandwidthChange = previousBandwidth ? ((bandwidth - previousBandwidth) / previousBandwidth) * 100 : 0;
        
        console.log(`[RB算法] 带宽变化: ${bandwidthChange.toFixed(1)}%, 缓冲区: ${bufferUsageRate.toFixed(1)}%, 当前质量: ${currentQualityLevel}`);
        
        // 基于带宽变化率的快速响应决策
        if (bandwidthChange > 15) {
            // 带宽显著增加，快速提升质量
            if (currentQualityLevel > 1) {
                newQualityLevel = Math.max(1, currentQualityLevel - 1);
                reason = `RB: 带宽增加${bandwidthChange.toFixed(1)}%，快速提升质量到${newQualityLevel}`;
            } else {
                reason = `RB: 带宽增加${bandwidthChange.toFixed(1)}%，但已达到最高质量`;
            }
        } else if (bandwidthChange < -15) {
            // 带宽显著下降，快速降低质量
            if (currentQualityLevel < 3) {
                newQualityLevel = Math.min(3, currentQualityLevel + 1);
                reason = `RB: 带宽下降${Math.abs(bandwidthChange).toFixed(1)}%，快速降低质量到${newQualityLevel}`;
            } else {
                reason = `RB: 带宽下降${Math.abs(bandwidthChange).toFixed(1)}%，但已达到最低质量`;
            }
        } else if (Math.abs(bandwidthChange) <= 5) {
            // 带宽稳定，基于缓冲区状态决策
            if (bufferUsageRate >= 75 && currentQualityLevel > 1) {
                newQualityLevel = 1;
                reason = `RB: 带宽稳定，缓冲区充足(${bufferUsageRate.toFixed(1)}%)，提升到最高质量`;
            } else if (bufferUsageRate <= 35 && currentQualityLevel < 3) {
                newQualityLevel = 3;
                reason = `RB: 带宽稳定，缓冲区不足(${bufferUsageRate.toFixed(1)}%)，降低到基础质量`;
            } else {
                // 带宽稳定，缓冲区适中，保持当前质量
                reason = `RB: 带宽稳定(${bandwidthChange.toFixed(1)}%)，缓冲区适中(${bufferUsageRate.toFixed(1)}%)，保持质量${currentQualityLevel}`;
            }
        } else {
            // 带宽变化在5%-15%之间，基于缓冲区状态做保守决策
            if (bufferUsageRate >= 80 && currentQualityLevel > 1) {
                newQualityLevel = Math.max(1, currentQualityLevel - 1);
                reason = `RB: 带宽变化${bandwidthChange.toFixed(1)}%，缓冲区充足(${bufferUsageRate.toFixed(1)}%)，保守提升质量到${newQualityLevel}`;
            } else if (bufferUsageRate <= 30 && currentQualityLevel < 3) {
                newQualityLevel = Math.min(3, currentQualityLevel + 1);
                reason = `RB: 带宽变化${bandwidthChange.toFixed(1)}%，缓冲区不足(${bufferUsageRate.toFixed(1)}%)，保守降低质量到${newQualityLevel}`;
            } else {
                reason = `RB: 带宽变化${bandwidthChange.toFixed(1)}%，缓冲区适中(${bufferUsageRate.toFixed(1)}%)，保持质量${currentQualityLevel}`;
            }
        }

        console.log(`[RB算法] 决策结果: ${reason}`);
        return { newQualityLevel, reason };
    }

    // RMPC (Robust Model Predictive Control) ABR算法
    rmpcDecision(bufferUsageRate, bandwidth, currentQualityLevel, previousBandwidth) {
        let newQualityLevel = currentQualityLevel;
        let reason = '';

        // 计算带宽变化率
        const bandwidthChange = previousBandwidth ? ((bandwidth - previousBandwidth) / previousBandwidth) * 100 : 0;
        
        // 基于预测模型的鲁棒决策
        if (bandwidthChange > 10) {
            // 带宽增加，预测性提升质量
            if (bufferUsageRate >= 70 && currentQualityLevel > 1) {
                newQualityLevel = Math.max(1, currentQualityLevel - 1);
                reason = `RMPC: 带宽增加${bandwidthChange.toFixed(1)}%，预测性提升质量到${newQualityLevel}`;
            }
        } else if (bandwidthChange < -10) {
            // 带宽下降，预测性降低质量
            if (currentQualityLevel < 3) {
                newQualityLevel = Math.min(3, currentQualityLevel + 1);
                reason = `RMPC: 带宽下降${Math.abs(bandwidthChange).toFixed(1)}%，预测性降低质量到${newQualityLevel}`;
            }
        } else {
            // 带宽稳定，基于预测模型和缓冲区状态决策
            if (bufferUsageRate >= 80 && currentQualityLevel > 1) {
                newQualityLevel = 1;
                reason = `RMPC: 带宽稳定，缓冲区充足(${bufferUsageRate.toFixed(1)}%)，预测模型建议提升到最高质量`;
            } else if (bufferUsageRate <= 40 && currentQualityLevel < 3) {
                newQualityLevel = 3;
                reason = `RMPC: 带宽稳定，缓冲区不足(${bufferUsageRate.toFixed(1)}%)，预测模型建议降低到基础质量`;
            } else if (bufferUsageRate >= 60 && bandwidth > 8) {
                // 基于带宽预测的主动提升
                if (currentQualityLevel > 1) {
                    newQualityLevel = Math.max(1, currentQualityLevel - 1);
                    reason = `RMPC: 带宽预测良好(${bandwidth.toFixed(1)}Mbps)，主动提升质量到${newQualityLevel}`;
                }
            }
        }

        return { newQualityLevel, reason };
    }

    // RL (Reinforcement Learning) ABR算法
    rlDecision(bufferUsageRate, bandwidth, currentQualityLevel, chunkIndex) {
        let newQualityLevel = currentQualityLevel;
        let reason = '';

        // 计算当前状态的特征
        const stateFeatures = this.extractRLStateFeatures(bufferUsageRate, bandwidth, currentQualityLevel);
        
        // 基于探索率决定是否探索新动作
        if (Math.random() < this.rlState.explorationRate) {
            // 探索：随机选择质量等级
            const availableQualities = [1, 2, 3].filter(q => q !== currentQualityLevel);
            newQualityLevel = availableQualities[Math.floor(Math.random() * availableQualities.length)];
            reason = `RL: 探索模式，随机选择质量等级${newQualityLevel}`;
        } else {
            // 利用：基于当前策略选择最佳动作
            newQualityLevel = this.selectBestQualityLevel(stateFeatures);
            reason = `RL: 利用模式，基于策略选择质量等级${newQualityLevel}`;
        }

        // 更新RL状态
        this.updateRLState(stateFeatures, newQualityLevel, bufferUsageRate);

        return { newQualityLevel, reason };
    }

    // 提取RL状态特征
    extractRLStateFeatures(bufferUsageRate, bandwidth, currentQualityLevel) {
        return {
            bufferLevel: this.categorizeBufferLevel(bufferUsageRate),
            bandwidthLevel: this.categorizeBandwidthLevel(bandwidth),
            currentQuality: currentQualityLevel
        };
    }

    // 分类缓冲区等级
    categorizeBufferLevel(bufferUsageRate) {
        if (bufferUsageRate >= this.bufferThresholds.high) return 'high';
        if (bufferUsageRate >= this.bufferThresholds.medium) return 'medium';
        return 'low';
    }

    // 分类带宽等级
    categorizeBandwidthLevel(bandwidth) {
        if (bandwidth > 10) return 'high';
        if (bandwidth > 5) return 'medium';
        return 'low';
    }

    // 选择最佳质量等级
    selectBestQualityLevel(stateFeatures) {
        const { bufferLevel, bandwidthLevel, currentQuality } = stateFeatures;
        
        // 基于缓冲区和带宽状态选择质量等级
        if (bufferLevel === 'high' && bandwidthLevel === 'high') {
            return 1; // 最高质量
        } else if (bufferLevel === 'high' || bandwidthLevel === 'high') {
            return 2; // 中等质量
        } else {
            return 3; // 基础质量
        }
    }

    // 更新RL状态
    updateRLState(stateFeatures, selectedQuality, bufferUsageRate) {
        // 计算奖励
        const qualityReward = this.rlState.qualityRewards[selectedQuality] || 0;
        const bufferReward = this.rlState.bufferRewards[stateFeatures.bufferLevel] || 0;
        const totalReward = qualityReward + bufferReward;

        // 更新探索率（随着时间减少探索）
        this.rlState.explorationRate = Math.max(0.01, this.rlState.explorationRate * 0.99);

        console.log(`[RL算法] 状态: ${JSON.stringify(stateFeatures)}, 选择质量: ${selectedQuality}, 奖励: ${totalReward.toFixed(2)}`);
    }

    // 重置RL状态
    resetRLState() {
        this.rlState.explorationRate = 0.1;
        console.log('[RL算法] 状态已重置');
    }

    // 重置RB状态
    resetRBState() {
        console.log('[RB算法] 状态已重置');
    }

    // 重置RMPC状态
    resetRMPCState() {
        console.log('[RMPC算法] 状态已重置');
    }

    // 获取算法统计信息
    getAlgorithmStats() {
        return {
            currentAlgorithm: this.currentAlgorithm,
            algorithmHistory: this.algorithmHistory,
            bufferThresholds: this.bufferThresholds,
            rlState: this.rlState
        };
    }

    // 获取算法切换历史
    getAlgorithmHistory() {
        return this.algorithmHistory;
    }
}

// 创建全局ABR管理器实例
export const abrManager = new ABRManager();
