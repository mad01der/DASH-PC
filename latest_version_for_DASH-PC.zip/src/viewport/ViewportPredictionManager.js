// 视口预测算法管理器
// 实现两种视口预测算法：LR (Linear Regression) 和 LSTM

import * as tf from '@tensorflow/tfjs';

export class ViewportPredictionManager {
  constructor() {
    this.currentAlgorithm = 'lr'; // 默认使用LR算法
    this.lstmModel = null; // LSTM模型实例
    this.isModelLoaded = false; // 模型加载状态
    this.algorithms = {
      'lr': {
        name: 'Linear Regression',
        description: '线性回归预测算法',
        predict: this.linearRegressionPredict.bind(this)
      },
      'lstm': {
        name: 'LSTM',
        description: '长短期记忆网络预测算法',
        predict: this.lstmPredict.bind(this)
      }
    };
    
    console.log(`[视口预测管理器] 初始化完成，当前算法: ${this.currentAlgorithm}`);
    
    // 预加载LSTM模型
    this.preloadLSTMModel();
  }

  // 预加载LSTM模型
  async preloadLSTMModel() {
    try {
      console.log('[视口预测管理器] 开始加载LSTM模型...');
      this.lstmModel = await tf.loadLayersModel('./models/tfjs_model/model.json');
      this.isModelLoaded = true;
      console.log('[视口预测管理器] LSTM模型加载成功');
    } catch (error) {
      console.error('[视口预测管理器] LSTM模型加载失败:', error);
      this.isModelLoaded = false;
    }
  }

  // 设置当前视口预测算法
  setAlgorithm(algorithm) {
    if (!this.algorithms[algorithm]) {
      console.error(`[视口预测管理器] 不支持的算法: ${algorithm}`);
      return false;
    }

    const oldAlgorithm = this.currentAlgorithm;
    this.currentAlgorithm = algorithm;
    
    // 如果切换到LSTM算法且模型未加载，尝试重新加载
    if (algorithm === 'lstm' && !this.isModelLoaded) {
      this.preloadLSTMModel();
    }
    
    console.log(`[视口预测管理器] 算法从 ${oldAlgorithm} 切换到 ${algorithm}`);
    return true;
  }

  // 获取当前算法
  getCurrentAlgorithm() {
    return this.currentAlgorithm;
  }

  // 获取算法信息
  getAlgorithmInfo(algorithm = null) {
    const targetAlgorithm = algorithm || this.currentAlgorithm;
    return this.algorithms[targetAlgorithm];
  }

  // 执行视口预测
  predict(cameraPositionHistory, futureSteps = 10) {
    const algorithm = this.algorithms[this.currentAlgorithm];
    if (!algorithm) {
      console.error(`[视口预测管理器] 算法未找到: ${this.currentAlgorithm}`);
      return null;
    }

    console.log(`[视口预测管理器] 使用${algorithm.name}算法进行预测`);
    return algorithm.predict(cameraPositionHistory, futureSteps);
  }

  // 线性回归预测算法 (LR)
  linearRegressionPredict(cameraPositionHistory, futureSteps) {
    if (cameraPositionHistory.length < 2) {
      console.log('[视口预测管理器] LR算法需要至少2个历史位置点');
      return null;
    }

    // 提取x, y, z坐标数据
    const xData = cameraPositionHistory.map(pos => pos.x);
    const yData = cameraPositionHistory.map(pos => pos.y);
    const zData = cameraPositionHistory.map(pos => pos.z);

    // 检查数据是否包含NaN或无效值
    const hasInvalidData = xData.some(x => isNaN(x) || !isFinite(x)) ||
                          yData.some(y => isNaN(y) || !isFinite(y)) ||
                          zData.some(z => isNaN(z) || !isFinite(z));
    
    if (hasInvalidData) {
      console.log('[视口预测管理器] LR算法检测到无效数据');
      return null;
    }

    const n = xData.length;
    
    // 计算x方向的线性回归
    const xSum = xData.reduce((a, b) => a + b, 0);
    const xSquaredSum = xData.reduce((a, b) => a + b * b, 0);
    const xProductSum = xData.map((x, i) => x * i).reduce((a, b) => a + b, 0);
    
    let xSlope, xIntercept;
    if (xSquaredSum === 0 && xSum === 0) {
      xSlope = 0;
      xIntercept = 0;
    } else {
      const xDenominator = n * xSquaredSum - xSum * xSum;
      if (Math.abs(xDenominator) < 1e-10) {
        xSlope = 0;
        xIntercept = xSum / n;
      } else {
        xSlope = (n * xProductSum - xSum * (n - 1) * n / 2) / xDenominator;
        xIntercept = (xSum - xSlope * (n - 1) * n / 2) / n;
      }
    }

    // 计算y方向的线性回归
    const ySum = yData.reduce((a, b) => a + b, 0);
    const ySquaredSum = yData.reduce((a, b) => a + b * b, 0);
    const yProductSum = yData.map((y, i) => y * i).reduce((a, b) => a + b, 0);
    
    let ySlope, yIntercept;
    if (ySquaredSum === 0 && ySum === 0) {
      ySlope = 0;
      yIntercept = 0;
    } else {
      const yDenominator = n * ySquaredSum - ySum * ySum;
      if (Math.abs(yDenominator) < 1e-10) {
        ySlope = 0;
        yIntercept = ySum / n;
      } else {
        ySlope = (n * yProductSum - ySum * (n - 1) * n / 2) / yDenominator;
        yIntercept = (ySum - ySlope * (n - 1) * n / 2) / n;
      }
    }

    // 计算z方向的线性回归
    const zSum = zData.reduce((a, b) => a + b, 0);
    const zSquaredSum = zData.reduce((a, b) => a + b * b, 0);
    const zProductSum = zData.map((z, i) => z * i).reduce((a, b) => a + b, 0);
    
    let zSlope, zIntercept;
    if (zSquaredSum === 0 && zSum === 0) {
      zSlope = 0;
      zIntercept = 0;
    } else {
      const zDenominator = n * zSquaredSum - zSum * zSum;
      if (Math.abs(zDenominator) < 1e-10) {
        zSlope = 0;
        zIntercept = zSum / n;
      } else {
        zSlope = (n * zProductSum - zSum * (n - 1) * n / 2) / zDenominator;
        zIntercept = (zSum - zSlope * (n - 1) * n / 2) / n;
      }
    }

    // 预测未来坐标
    const predictions = [];
    for (let i = 0; i < futureSteps; i++) {
      const futureIndex = n + i;
      const predictedX = xSlope * futureIndex + xIntercept;
      const predictedY = ySlope * futureIndex + yIntercept;
      const predictedZ = zSlope * futureIndex + zIntercept;
      predictions.push({ x: predictedX, y: predictedY, z: predictedZ });
    }

    return {
      algorithm: 'lr',
      predictions,
      slopes: { x: xSlope, y: ySlope, z: zSlope },
      intercepts: { x: xIntercept, y: yIntercept, z: zIntercept },
      confidence: this.calculateLRConfidence(cameraPositionHistory, predictions)
    };
  }

  // LSTM预测算法 (真实实现)
  async lstmPredict(cameraPositionHistory, futureSteps) {
    if (cameraPositionHistory.length < 20) {
      console.log('[视口预测管理器] LSTM算法需要至少20个历史位置点');
      return null;
    }

    // 检查模型是否已加载
    if (!this.isModelLoaded || !this.lstmModel) {
      console.log('[视口预测管理器] LSTM模型未加载，尝试重新加载...');
      await this.preloadLSTMModel();
      if (!this.isModelLoaded) {
        console.error('[视口预测管理器] LSTM模型加载失败，无法进行预测');
        return null;
      }
    }

    try {
      // 检查数据有效性
      const hasInvalidData = cameraPositionHistory.some(pos => 
        isNaN(pos.x) || isNaN(pos.y) || isNaN(pos.z) ||
        !isFinite(pos.x) || !isFinite(pos.y) || !isFinite(pos.z)
      );
      
      if (hasInvalidData) {
        console.log('[视口预测管理器] LSTM算法检测到无效数据');
        return null;
      }

      // 准备输入数据：取最后20个位置点，每个点包含x,y,z坐标
      const inputData = cameraPositionHistory.slice(-20).map(pos => [pos.x, pos.y, pos.z]);
      
      // 数据标准化：计算均值和标准差
      const mean = [0, 0, 0];
      const std = [0, 0, 0];
      
      // 计算均值
      for (let i = 0; i < 3; i++) {
        mean[i] = inputData.reduce((sum, pos) => sum + pos[i], 0) / inputData.length;
      }
      
      // 计算标准差
      for (let i = 0; i < 3; i++) {
        const variance = inputData.reduce((sum, pos) => sum + Math.pow(pos[i] - mean[i], 2), 0) / inputData.length;
        std[i] = Math.sqrt(variance);
      }
      
      // 标准化数据
      const normalizedData = inputData.map(pos => 
        pos.map((val, i) => (val - mean[i]) / (std[i] + 1e-8))
      );
      
      // 转换为TensorFlow.js张量格式 [batch_size, sequence_length, features]
      const inputTensor = tf.tensor3d([normalizedData], [1, 20, 3]);
      
      // 使用模型进行预测
      const prediction = this.lstmModel.predict(inputTensor);
      
      // 获取预测结果
      const predictionArray = await prediction.array();
      
      // 反标准化预测结果
      const denormalizedPredictions = predictionArray[0].map(pos => ({
        x: pos[0] * (std[0] + 1e-8) + mean[0],
        y: pos[1] * (std[1] + 1e-8) + mean[1],
        z: pos[2] * (std[2] + 1e-8) + mean[2]
      }));
      
      // 清理张量内存
      inputTensor.dispose();
      prediction.dispose();
      
      // 如果预测步数少于请求的步数，进行扩展
      const predictions = [];
      if (denormalizedPredictions.length >= futureSteps) {
        predictions.push(...denormalizedPredictions.slice(0, futureSteps));
      } else {
        // 如果预测步数不足，使用最后几个预测点进行线性外推
        predictions.push(...denormalizedPredictions);
        
        if (denormalizedPredictions.length > 0) {
          const lastPred = denormalizedPredictions[denormalizedPredictions.length - 1];
          const secondLastPred = denormalizedPredictions[denormalizedPredictions.length - 2] || lastPred;
          
          const dx = lastPred.x - secondLastPred.x;
          const dy = lastPred.y - secondLastPred.y;
          const dz = lastPred.z - secondLastPred.z;
          
          for (let i = denormalizedPredictions.length; i < futureSteps; i++) {
            const step = i - denormalizedPredictions.length + 1;
            predictions.push({
              x: lastPred.x + dx * step,
              y: lastPred.y + dy * step,
              z: lastPred.z + dz * step
            });
          }
        }
      }

      return {
        algorithm: 'lstm',
        predictions,
        parameters: {
          sequenceLength: cameraPositionHistory.length,
          inputShape: [20, 3],
          normalization: { mean, std },
          modelLoaded: this.isModelLoaded
        },
        confidence: this.calculateLSTMConfidence(cameraPositionHistory, predictions)
      };
      
    } catch (error) {
      console.error('[视口预测管理器] LSTM预测过程中发生错误:', error);
      
      // 如果LSTM预测失败，回退到简化的预测方法
      console.log('[视口预测管理器] 回退到简化预测方法');
      return this.fallbackLSTMPredict(cameraPositionHistory, futureSteps);
    }
  }

  // LSTM预测失败时的回退方法
  fallbackLSTMPredict(cameraPositionHistory, futureSteps) {
    if (cameraPositionHistory.length < 5) {
      console.log('[视口预测管理器] 回退方法需要至少5个历史位置点');
      return null;
    }

    // 简化的LSTM模拟实现
    const predictions = [];
    const lastPos = cameraPositionHistory[cameraPositionHistory.length - 1];
    const secondLastPos = cameraPositionHistory[cameraPositionHistory.length - 2];
    
    // 计算移动趋势
    const dx = lastPos.x - secondLastPos.x;
    const dy = lastPos.y - secondLastPos.y;
    const dz = lastPos.z - secondLastPos.z;
    
    // 使用指数平滑进行预测
    const alpha = 0.8; // 平滑因子
    
    for (let i = 0; i < futureSteps; i++) {
      const decayFactor = Math.pow(alpha, i + 1);
      const predictedX = lastPos.x + dx * decayFactor * (i + 1);
      const predictedY = lastPos.y + dy * decayFactor * (i + 1);
      const predictedZ = lastPos.z + dz * decayFactor * (i + 1);
      
      predictions.push({ x: predictedX, y: predictedY, z: predictedZ });
    }

    return {
      algorithm: 'lstm_fallback',
      predictions,
      parameters: {
        alpha: alpha,
        trend: { dx, dy, dz },
        sequenceLength: cameraPositionHistory.length,
        fallback: true
      },
      confidence: this.calculateLSTMConfidence(cameraPositionHistory, predictions) * 0.7 // 回退方法置信度降低
    };
  }

  // 计算LR算法的置信度
  calculateLRConfidence(history, predictions) {
    if (history.length < 2) return 0;
    
    // 基于历史数据的方差计算置信度
    const xVariance = this.calculateVariance(history.map(pos => pos.x));
    const yVariance = this.calculateVariance(history.map(pos => pos.y));
    const zVariance = this.calculateVariance(history.map(pos => pos.z));
    
    // 方差越小，置信度越高
    const avgVariance = (xVariance + yVariance + zVariance) / 3;
    const confidence = Math.max(0, 1 - avgVariance / 100); // 归一化到0-1
    
    return Math.min(1, confidence);
  }

  // 计算LSTM算法的置信度
  calculateLSTMConfidence(history, predictions) {
    if (history.length < 20) return 0;
    
    // 基于序列长度和预测一致性计算置信度
    const sequenceLength = history.length;
    const baseConfidence = Math.min(1, sequenceLength / 30); // 序列越长，基础置信度越高
    
    // 检查预测的合理性（预测值不应该偏离历史范围太远）
    const xRange = this.getRange(history.map(pos => pos.x));
    const yRange = this.getRange(history.map(pos => pos.y));
    const zRange = this.getRange(history.map(pos => pos.z));
    
    const predictionsInRange = predictions.filter(pred => 
      pred.x >= xRange.min - xRange.range * 0.5 && pred.x <= xRange.max + xRange.range * 0.5 &&
      pred.y >= yRange.min - yRange.range * 0.5 && pred.y <= yRange.max + yRange.range * 0.5 &&
      pred.z >= zRange.min - zRange.range * 0.5 && pred.z <= zRange.max + zRange.range * 0.5
    );
    
    const rangeConfidence = predictionsInRange.length / predictions.length;
    
    // 如果模型已加载，提高置信度
    const modelBonus = this.isModelLoaded ? 0.2 : 0;
    
    return Math.min(1, (baseConfidence + rangeConfidence) / 2 + modelBonus);
  }

  // 计算方差
  calculateVariance(values) {
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const squaredDiffs = values.map(val => Math.pow(val - mean, 2));
    return squaredDiffs.reduce((a, b) => a + b, 0) / values.length;
  }

  // 获取范围
  getRange(values) {
    const min = Math.min(...values);
    const max = Math.max(...values);
    return { min, max, range: max - min };
  }

  // 获取所有支持的算法
  getSupportedAlgorithms() {
    return Object.keys(this.algorithms);
  }

  // 获取LSTM模型状态
  getLSTMModelStatus() {
    return {
      isLoaded: this.isModelLoaded,
      algorithm: this.currentAlgorithm
    };
  }

  // 重置管理器状态
  reset() {
    this.currentAlgorithm = 'lr';
    console.log('[视口预测管理器] 状态已重置');
  }

  // 清理资源
  dispose() {
    if (this.lstmModel) {
      this.lstmModel.dispose();
      this.lstmModel = null;
    }
    this.isModelLoaded = false;
    console.log('[视口预测管理器] 资源已清理');
  }
}

// 创建全局视口预测管理器实例
export const viewportPredictionManager = new ViewportPredictionManager();
