// RL Agent数据记录器
// 用于记录播放过程中的action选择、Q值等数据

export class RLDataRecorder {
  constructor() {
    this.recordingData = [];
    this.isRecording = false;
    this.startTime = null;
    this.frameCount = 0;
    
    console.log('[RL数据记录器] 初始化完成');
  }

  // 开始记录
  startRecording() {
    this.recordingData = [];
    this.isRecording = true;
    this.startTime = Date.now();
    this.frameCount = 0;
    
    console.log('[RL数据记录器] 开始记录数据');
  }

  // 停止记录
  stopRecording() {
    this.isRecording = false;
    console.log('[RL数据记录器] 停止记录数据，共记录', this.recordingData.length, '条');
  }

  // 记录一次预测数据
  recordPredictionData(action, qValues, state, reward, confidence, algorithm) {
    if (!this.isRecording) return;
    
    this.frameCount++;
    
    const record = {
      timestamp: Date.now(),
      frameCount: this.frameCount,
      relativeTime: this.startTime ? Date.now() - this.startTime : 0,
      state: state,
      action: action,
      qValues: { ...qValues }, // 复制Q值对象
      reward: reward,
      confidence: confidence,
      algorithm: algorithm,
      cameraPosition: this.getCurrentCameraPosition()
    };
    
    this.recordingData.push(record);
    
    console.log(`[RL数据记录器] 记录第${this.frameCount}帧: 动作${action}, 奖励${reward?.toFixed(4)}`);
  }

  // 更新最后一条记录的奖励
  updateLastRecordReward(reward) {
    if (this.recordingData.length > 0) {
      const lastRecord = this.recordingData[this.recordingData.length - 1];
      lastRecord.reward = reward;
      console.log(`[RL数据记录器] 更新第${lastRecord.frameCount}帧奖励: ${reward.toFixed(4)}`);
    }
  }

  // 获取当前摄像头位置
  getCurrentCameraPosition() {
    // 从全局camera对象获取位置
    if (window.camera) {
      return {
        x: window.camera.position.x,
        y: window.camera.position.y,
        z: window.camera.position.z
      };
    }
    return { x: 0, y: 0, z: 0 };
  }

  // 获取记录的数据
  getRecordingData() {
    return this.recordingData;
  }

  // 清空记录数据
  clearData() {
    this.recordingData = [];
    this.frameCount = 0;
    console.log('[RL数据记录器] 数据已清空');
  }

  // 导出为CSV格式
  exportToCSV(filename = 'rl_agent_data.csv') {
    if (this.recordingData.length === 0) {
      console.warn('[RL数据记录器] 没有数据可导出');
      return null;
    }

    try {
      // CSV头部
      const headers = [
        '时间戳',
        '帧数',
        '相对时间(ms)',
        '状态',
        '动作',
        'Q值_动作0',
        'Q值_动作1', 
        'Q值_动作2',
        'Q值_动作3',
        'Q值_动作4',
        '奖励',
        '置信度',
        '算法',
        '摄像头X',
        '摄像头Y',
        '摄像头Z'
      ];

      // CSV数据行
      const csvRows = [headers.join(',')];
      
      for (const record of this.recordingData) {
        const row = [
          record.timestamp,
          record.frameCount,
          record.relativeTime,
          `"${record.state}"`,
          record.action,
          record.qValues[0] || 0,
          record.qValues[1] || 0,
          record.qValues[2] || 0,
          record.qValues[3] || 0,
          record.qValues[4] || 0,
          record.reward || 0,
          record.confidence || 0,
          `"${record.algorithm}"`,
          record.cameraPosition.x,
          record.cameraPosition.y,
          record.cameraPosition.z
        ];
        csvRows.push(row.join(','));
      }

      const csvContent = csvRows.join('\n');
      
      // 创建下载链接
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      
      if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        console.log(`[RL数据记录器] 数据已导出到 ${filename}`);
        return true;
      } else {
        console.error('[RL数据记录器] 浏览器不支持下载');
        return false;
      }
      
    } catch (error) {
      console.error('[RL数据记录器] 导出CSV失败:', error);
      return false;
    }
  }

  // 获取统计信息
  getStatistics() {
    if (this.recordingData.length === 0) {
      return {
        totalRecords: 0,
        totalFrames: 0,
        averageReward: 0,
        actionDistribution: {},
        algorithmDistribution: {}
      };
    }

    const totalRecords = this.recordingData.length;
    const totalFrames = this.frameCount;
    
    // 计算平均奖励
    const totalReward = this.recordingData.reduce((sum, record) => sum + (record.reward || 0), 0);
    const averageReward = totalReward / totalRecords;
    
    // 统计动作分布
    const actionDistribution = {};
    for (let i = 0; i < 5; i++) {
      actionDistribution[i] = this.recordingData.filter(record => record.action === i).length;
    }
    
    // 统计算法分布
    const algorithmDistribution = {};
    this.recordingData.forEach(record => {
      const algo = record.algorithm || 'unknown';
      algorithmDistribution[algo] = (algorithmDistribution[algo] || 0) + 1;
    });

    return {
      totalRecords,
      totalFrames,
      averageReward,
      actionDistribution,
      algorithmDistribution
    };
  }

  // 重置记录器
  reset() {
    this.stopRecording();
    this.clearData();
    this.startTime = null;
    console.log('[RL数据记录器] 记录器已重置');
  }
}

// 创建全局RL数据记录器实例
export const rlDataRecorder = new RLDataRecorder();
