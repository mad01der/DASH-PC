import * as THREE from "three"
import { viewportPredictionManager } from "../viewport/ViewportPredictionManager.js";

const camera = new THREE.PerspectiveCamera(
    45,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
);

camera.position.set(0,0,10);

// ====== 视口预测模块 ======
let cameraPositionHistory = []; // 存储摄像头坐标历史
let frameCountForPrediction = 0; // 用于计数每5帧
const PREDICTION_INTERVAL = 5; // 每5帧预测一次
const PREDICTION_FRAMES = 10; // 预测未来10帧

// 视口预测主函数
async function performViewportPrediction() {
  if (cameraPositionHistory.length < 2) {
    return null;
  }

  try {
    // 使用视口预测管理器进行预测
    const result = await viewportPredictionManager.predict(cameraPositionHistory, PREDICTION_FRAMES);
    
    if (result) {
      console.log(`[视口预测] 使用${result.algorithm}算法完成预测，置信度: ${result.confidence.toFixed(3)}`);
    }
    
    return result;
  } catch (error) {
    console.error('[视口预测] 预测失败:', error);
    return null;
  }
}

// 更新摄像头位置历史
export function updateCameraPositionHistory() {
  const currentPos = camera.position.clone();
  
  // 检查位置是否有效
  if (isNaN(currentPos.x) || isNaN(currentPos.y) || isNaN(currentPos.z) ||
      !isFinite(currentPos.x) || !isFinite(currentPos.y) || !isFinite(currentPos.z)) {
    console.log('[视口预测] 摄像头位置无效，跳过记录');
    return;
  }
  
  cameraPositionHistory.push(currentPos);
  
  // 保持历史记录在合理范围内（最多保留20个点）
  if (cameraPositionHistory.length > 20) {
    cameraPositionHistory.shift();
  }
  
  frameCountForPrediction++;
  
  // 每5帧执行一次预测
  if (frameCountForPrediction >= PREDICTION_INTERVAL) {
    performViewportPrediction();
    frameCountForPrediction = 0; // 重置计数器
  }
}

// 重置预测模块
export function resetViewportPrediction() {
  cameraPositionHistory = [];
  frameCountForPrediction = 0;
  console.log('[视口预测] 预测模块已重置');
}

// 获取最新的预测结果
export async function getLatestPrediction() {
  if (cameraPositionHistory.length < 2) {
    return null;
  }
  
  try {
    return await viewportPredictionManager.predict(cameraPositionHistory, PREDICTION_FRAMES);
  } catch (error) {
    console.error('[视口预测] 获取最新预测失败:', error);
    return null;
  }
}

export default camera;
